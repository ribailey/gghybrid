## =============================================================================
## esth_fast: exact Bayesian hybrid index without MCMC
## Part of the gghybrid 3.0.0 _fast function set.
## =============================================================================
##
## Each hybrid-index unit (individual, population, locus, ...) is a
## one-parameter problem, so the posterior is computed exactly by quadrature.
##
## Working scale: phi = asin(sqrt(h)), phi in [0, pi/2].
##   * h = sin(phi)^2, dh/dphi = sin(2 phi).
##   * A Beta(a, b) prior on h becomes  sin(phi)^(2a-1) cos(phi)^(2b-1)  on phi.
##     For the default Jeffreys prior (a = b = 0.5) this is constant: the
##     posterior on phi is proportional to the likelihood alone.
##   * phi is the variance-stabilising transform for binomial data, so posterior
##     widths on phi are roughly constant across h, and a unit whose likelihood
##     peaks at h = 0 has a smooth half-normal posterior at phi = 0 rather than
##     a spike.
##
## Algorithm, all units in lockstep:
##   1. coarse grid (129 points in phi) by sparse matrix products -> bracket
##   2. safeguarded Newton on phi inside the bracket -> mode and curvature
##   3. G-node grid over mode +/- 8 SD (widened automatically if the tails
##      are not captured) -> exact log posterior at the nodes
##   4. cubic-spline refinement to a fine grid -> mean, variance, equal-tailed
##      quantiles and the posterior mode of h
##   5. optional per-observation likelihood moments (likmeans) by quadrature
##      over the nodes, in the format compare.models() expects
##
## Cost: about 10 + G passes over the (unit x locus) count cells, streamed in
## locus chunks. No MCMC tuning, burn-in or Monte Carlo error.
## =============================================================================

## ---- small helpers ---------------------------------------------------------

## n * log(x) with 0 * log(0) = 0
.xlogy <- function(n, x) { v <- n * log(x); v[is.nan(v)] <- 0; v }
## n / x with 0 / 0 = 0
.xdivy <- function(n, x) { v <- n / x; v[is.nan(v)] <- 0; v }

## Log density on phi of the terms  ca*log(sin phi) + cb*log(cos phi), and its
## first two derivatives. ca, cb may be per-unit vectors (recycled down the
## rows of a units x grid matrix). They combine the Beta prior (2a-1, 2b-1)
## with the exactly known singular part of the likelihood at h = 0 or 1
## (loci where a parental frequency is exactly 0 or 1).
.hi_prior_phi <- function(phi, ca, cb) {
  s <- sin(phi); c <- cos(phi)
  lp <- .xlogy(ca, s) + .xlogy(cb, c)
  d1 <- .xdivy(ca * c, s) - .xdivy(cb * s, c)
  d2 <- -.xdivy(ca, s^2) - .xdivy(cb, c^2)
  list(lp = lp, d1 = d1, d2 = d2)
}

## Spline interpolation matrix: values at G uniform nodes on [0,1] -> Gf fine
## points. The FMM spline is linear in the data, so interpolation of every
## unit at once is one matrix product.
.spline_matrix <- function(G, Gf) {
  t  <- seq(0, 1, length.out = G)
  tf <- seq(0, 1, length.out = Gf)
  M  <- matrix(0, G, Gf)
  for (g in seq_len(G)) {
    e <- numeric(G); e[g] <- 1
    M[g, ] <- stats::splinefun(t, e, method = "fmm")(tf)
  }
  M
}

## split cell indices (cells sorted by locus) into locus chunks
.cell_chunks <- function(loc, chunk.cells) {
  K <- length(loc)
  if (K <= chunk.cells) return(list(seq_len(K)))
  brk <- which(diff(loc) != 0)            # last cell of each locus
  ends <- unique(c(brk[findInterval(seq(chunk.cells, K, by = chunk.cells), brk)], K))
  ends <- ends[ends > 0]
  starts <- c(1L, head(ends, -1) + 1L)
  mapply(seq.int, starts, ends, SIMPLIFY = FALSE)
}


## ---- core engine -----------------------------------------------------------
## cells: data.table with integer unit (1..U), loc (1..L), numeric n1, n0,
##        sorted by loc. S0, D: per-locus vectors (D = S1 - S0).
## Returns per-unit summaries and, if requested, per-cell likelihood moments.
##
## Singular end-points. Where S0 = 0, the allele-1 term is
##   log(D h) = log D + 2 log sin(phi),
## and where S1 = 1 the allele-0 term is log D + 2 log cos(phi). These factors
## send the likelihood to exactly zero at h = 0 or 1. They are removed from
## the cells and added, exactly, to per-unit exponents ca, cb alongside the
## prior, so the remainder that gets interpolated is smooth on [0, pi/2].

.esth_engine <- function(cells, U, S0, D, prior = c(0.5, 0.5),
                         G = 64L, Gf = 1024L, G0 = 129L, n.sd = 8,
                         newton.maxit = 50L, tol = 1e-10,
                         chunk.cells = 2e5, want.cellmoments = FALSE) {

  half <- pi / 2
  chunks <- .cell_chunks(cells$loc, chunk.cells)
  unit <- cells$unit; loc <- cells$loc
  S1 <- S0 + D
  z0 <- S0[loc] <= 0; z1 <- S1[loc] >= 1
  n1 <- ifelse(z0, 0, cells$n1)                  # smooth part only
  n0 <- ifelse(z1, 0, cells$n0)
  k0 <-
        vapply(split(cells$n1[z0], factor(unit[z0], levels = seq_len(U))), sum, 0)
  k1 <- vapply(split(cells$n0[z1], factor(unit[z1], levels = seq_len(U))), sum, 0)
  ca <- (2 * prior[1] - 1) + 2 * k0
  cb <- (2 * prior[2] - 1) + 2 * k1

  ## smooth log likelihood on a per-unit grid of phi (U x ncol(PHI)) -------
  ll_grid <- function(PHI) {
    Hh <- sin(PHI)^2
    out <- matrix(0, U, ncol(PHI))
    for (ix in chunks) {
      A  <- S0[loc[ix]] + D[loc[ix]] * Hh[unit[ix], , drop = FALSE]
      v  <- .xlogy(n1[ix], A) + .xlogy(n0[ix], 1 - A)
      rs <- rowsum(v, unit[ix], reorder = TRUE)
      ug <- as.integer(rownames(rs))
      out[ug, ] <- out[ug, ] + rs
    }
    out
  }

  ## ---- 1. coarse grid by sparse products --------------------------------
  phi0 <- seq(0, half, length.out = G0)
  h0   <- sin(phi0)^2
  lp0  <- matrix(0, U, G0)
  for (ix in chunks) {
    lj <- sort(unique(loc[ix])); lmap <- match(loc[ix], lj)
    k_1 <- n1[ix] > 0; k_0 <- n0[ix] > 0
    B1 <- Matrix::sparseMatrix(i = unit[ix][k_1], j = lmap[k_1], x = n1[ix][k_1],
                               dims = c(U, length(lj)))
    B0 <- Matrix::sparseMatrix(i = unit[ix][k_0], j = lmap[k_0], x = n0[ix][k_0],
                               dims = c(U, length(lj)))
    A  <- outer(S0[lj], rep(1, G0)) + outer(D[lj], h0)
    ## finite floor keeps the product free of 0 * -Inf; with the singular
    ## factors removed, log(0) cannot arise for a nonzero count anyway
    LQ <- pmax(log(A), -1e12); LR <- pmax(log1p(-A), -1e12)
    lp0 <- lp0 + as.matrix(B1 %*% LQ) + as.matrix(B0 %*% LR)
  }
  PH0 <- matrix(phi0, U, G0, byrow = TRUE)
  lp0 <- lp0 + .hi_prior_phi(PH0, ca, cb)$lp
  m0  <- max.col(lp0, ties.method = "first")
  lo  <- phi0[pmax(m0 - 1L, 1L)]
  hi  <- phi0[pmin(m0 + 1L, G0)]
  phi <- phi0[m0]

  ## ---- 2. safeguarded Newton ---------------------------------------------
  ## gradient-sign bracketing makes this globally convergent for a unimodal
  ## posterior; Newton steps give quadratic convergence near the mode
  grad_hess <- function(phi) {
    h <- sin(phi)^2
    G1 <- G2 <- numeric(U)
    for (ix in chunks) {
      a  <- S0[loc[ix]] + D[loc[ix]] * h[unit[ix]]
      Dl <- D[loc[ix]]
      d1 <- Dl * (.xdivy(n1[ix], a) - .xdivy(n0[ix], 1 - a))
      d2 <- -Dl^2 * (.xdivy(n1[ix], a^2) + .xdivy(n0[ix], (1 - a)^2))
      rs <- rowsum(cbind(d1, d2), unit[ix], reorder = TRUE)
      ug <- as.integer(rownames(rs))
      G1[ug] <- G1[ug] + rs[, 1]; G2[ug] <- G2[ug] + rs[, 2]
    }
    s2 <- sin(2 * phi); c2 <- cos(2 * phi)
    pr <- .hi_prior_phi(phi, ca, cb)
    g  <- G1 * s2 + pr$d1
    H  <- G2 * s2^2 + 2 * G1 * c2 + pr$d2
    list(g = g, H = H)
  }

  active <- rep(TRUE, U)
  for (it in seq_len(newton.maxit)) {
    gh <- grad_hess(phi)
    g <- gh$g; H <- gh$H
    bad <- !is.finite(g)
    up  <- ifelse(bad, phi < (lo + hi) / 2, g > 0)
    lo[active & up]  <- phi[active & up]
    hi[active & !up] <- phi[active & !up]
    stat <- !bad & abs(g) < 1e-12                # stationary point
    nt  <- phi - g / H
    ok  <- is.finite(nt) & H < 0
    ## a Newton step past a domain end-point lands on the end-point
    nt[ok & nt < 0 & lo == 0] <- 0
    nt[ok & nt > half & hi == half] <- half
    ok  <- ok & nt >= lo & nt <= hi
    cand <- ifelse(ok, nt, (lo + hi) / 2)
    cand[stat] <- phi[stat]
    step <- abs(cand - phi)
    phi[active] <- cand[active]
    active <- active & !(stat | step < tol | (hi - lo) < tol)
    if (!any(active)) break
  }
  gh <- grad_hess(phi)
  sd_phi <- ifelse(is.finite(gh$H) & gh$H < 0, 1 / sqrt(-gh$H), half / 4)
  sd_phi <- pmin(sd_phi, half)
  newton_conv <- !active

  ## ---- 3. node grid with automatic tail check ----------------------------
  tt <- seq(0, 1, length.out = G)
  wlo <- pmax(0, phi - n.sd * sd_phi)
  whi <- pmin(half, phi + n.sd * sd_phi)
  todo <- rep(TRUE, U)
  LLN <- matrix(NA_real_, U, G)                   # smooth part at nodes
  for (pass in 1:8) {
    idx <- which(todo)
    PHIall <- matrix(phi, U, G)
    PHIall[idx, ] <- wlo[idx] + outer(whi[idx] - wlo[idx], tt)
    LLN[idx, ] <- ll_grid(PHIall)[idx, , drop = FALSE]
    lpn <- LLN[idx, , drop = FALSE] +
           .hi_prior_phi(PHIall[idx, , drop = FALSE], ca[idx], cb[idx])$lp
    mx <- apply(lpn, 1, max)
    lo_ok <- wlo[idx] == 0    | lpn[, 1] < mx - 25
    hi_ok <- whi[idx] == half | lpn[, G] < mx - 25
    todo[] <- FALSE
    fail <- !(lo_ok & hi_ok)
    if (!any(fail)) break
    grow <- idx[fail]
    todo[grow] <- TRUE
    ctr <- (wlo[grow] + whi[grow]) / 2; hw <- (whi[grow] - wlo[grow]) / 2
    wlo[grow] <- ifelse(lo_ok[fail], wlo[grow], pmax(0, ctr - 1.7 * hw))
    whi[grow] <- ifelse(hi_ok[fail], whi[grow], pmin(half, ctr + 1.7 * hw))
  }
  tail_ok <- !todo

  ## ---- 4. fine-grid summaries -------------------------------------------
  M   <- .spline_matrix(G, Gf)
  tf  <- seq(0, 1, length.out = Gf)
  PHF <- wlo + outer(whi - wlo, tf)
  LPF <- LLN %*% M + .hi_prior_phi(PHF, ca, cb)$lp
  P   <- exp(LPF - apply(LPF, 1, max))
  P[!is.finite(P)] <- 0
  dt  <- (whi - wlo) / (Gf - 1)
  inc <- (P[, -1, drop = FALSE] + P[, -Gf, drop = FALSE]) / 2 * dt
  CDF <- cbind(0, t(apply(inc, 1, cumsum)))
  if (U == 1) CDF <- matrix(CDF, 1)
  Z   <- CDF[, Gf]
  CDF <- CDF / Z
  tw  <- matrix(dt, U, Gf); tw[, c(1, Gf)] <- tw[, c(1, Gf)] / 2
  W   <- P * tw / Z
  HF  <- sin(PHF)^2
  h_mean <- rowSums(W * HF)
  h_var  <- pmax(rowSums(W * HF^2) - h_mean^2, 0)

  qfun <- function(p) {
    j  <- pmin(pmax(rowSums(CDF < p), 1L), Gf - 1L)
    i1 <- cbind(seq_len(U), j); i2 <- cbind(seq_len(U), j + 1L)
    c1 <- CDF[i1]; c2 <- CDF[i2]
    fr <- ifelse(c2 > c1, (p - c1) / (c2 - c1), 0)
    sin(PHF[i1] + fr * (PHF[i2] - PHF[i1]))^2
  }
  h_lo <- qfun(0.025); h_hi <- qfun(0.975); h_med <- qfun(0.5)

  ## Posterior mode of h. The density of h is p_phi / sin(2 phi), which under
  ## a prior shape < 1 is unbounded at 0 or 1. The mode is taken as the
  ## highest interior local maximum; if there is none, the density rises all
  ## the way to a boundary and the mode is that boundary (0 or 1), matching
  ## esth's rule for Beta shapes below 1.
  LPH <- LLN %*% M + .hi_prior_phi(PHF, ca - 1, cb - 1)$lp
  inner <- 2:(Gf - 1)
  LM <- matrix(FALSE, U, Gf)
  LM[, inner] <- LPH[, inner] >= LPH[, inner - 1] & LPH[, inner] > LPH[, inner + 1] &
                 is.finite(LPH[, inner])
  cand <- ifelse(LM, LPH, -Inf)
  has_int <- rowSums(LM) > 0
  jm <- max.col(cand, ties.method = "first")
  j1 <- pmax(jm - 1L, 1L); j3 <- pmin(jm + 1L, Gf)
  y1 <- LPH[cbind(seq_len(U), j1)]; y2 <- LPH[cbind(seq_len(U), jm)]
  y3 <- LPH[cbind(seq_len(U), j3)]
  den <- y1 - 2 * y2 + y3
  off <- ifelse(is.finite(den) & den < 0, 0.5 * (y1 - y3) / den, 0)
  off <- pmin(pmax(off, -1), 1)
  h_mode <- sin(PHF[cbind(seq_len(U), jm)] + off * dt)^2
  ## no interior maximum: mode at whichever boundary the density rises to
  to0 <- !has_int & wlo == 0 & (LPH[, 1] >= LPH[, Gf] | whi < half)
  h_mode[!has_int] <- 1
  h_mode[to0] <- 0

  res <- list(h_mode = h_mode, h_mean = h_mean, h_var = h_var,
              h_lo = h_lo, h_hi = h_hi, h_median = h_med,
              phi_mode = phi, phi_sd = sd_phi,
              newton_converged = newton_conv, tails_ok = tail_ok,
              wlo = wlo, whi = whi)

  ## ---- 5. per-cell likelihood moments (for likmeans) ---------------------
  if (want.cellmoments) {
    ## trapezoid weights at the nodes from the full log posterior; nodes with
    ## negligible mass are zeroed, which also removes log(0) at end-points
    PHN <- wlo + outer(whi - wlo, tt)
    LPN <- LLN + .hi_prior_phi(PHN, ca, cb)$lp
    mxn <- apply(LPN, 1, max)
    PN <- exp(LPN - mxn); PN[!is.finite(LPN) | LPN < mxn - 40] <- 0
    twn <- matrix((whi - wlo) / (G - 1), U, G); twn[, c(1, G)] <- twn[, c(1, G)] / 2
    WN <- PN * twn; WN <- WN / rowSums(WN)
    HN <- sin(PHN)^2
    K  <- nrow(cells)
    mom <- matrix(0, K, 6,
                  dimnames = list(NULL, c("m1_lq", "m2_lq", "m_q",
                                          "m1_lr", "m2_lr", "m_r")))
    for (ix in chunks) {
      Wc <- WN[unit[ix], , drop = FALSE]
      A  <- S0[loc[ix]] + D[loc[ix]] * HN[unit[ix], , drop = FALSE]
      LQ <- log(A); LR <- log1p(-A)
      LQ[Wc == 0] <- 0; LR[Wc == 0] <- 0
      mom[ix, 1] <- rowSums(Wc * LQ);  mom[ix, 2] <- rowSums(Wc * LQ^2)
      mom[ix, 3] <- rowSums(Wc * A)
      mom[ix, 4] <- rowSums(Wc * LR);  mom[ix, 5] <- rowSums(Wc * LR^2)
      mom[ix, 6] <- rowSums(Wc * (1 - A))
    }
    res$cellmoments <- mom
  }
  res
}


## ---- source allele frequencies -------------------------------------------
## Per-locus counts of allele-1 copies (N1) and all copies (N) in each
## parental reference sample, from the reference rows themselves.
.source_counts <- function(d, loc_levels) {
  f <- d[Source %in% c("S0", "S1"),
         .(N1 = sum(Source_allele == 1), N = .N), by = .(Source, locus)]
  out <- list()
  for (src in c("S0", "S1")) {
    g <- f[Source == src]
    m <- match(loc_levels, g$locus)
    out[[src]] <- list(N1 = ifelse(is.na(m), 0, g$N1[m]),
                       N  = ifelse(is.na(m), 0, g$N[m]))
  }
  out
}

## Summaries from an engine run, as columns
.eng_cols <- function(eng) {
  list(h_posterior_mode = eng$h_mode, h_cred_int_lower = eng$h_lo,
       h_cred_int_upper = eng$h_hi, beta_mean = eng$h_mean,
       beta_var = eng$h_var, h_posterior_median = eng$h_median,
       quad_ok = eng$tails_ok & eng$newton_converged)
}


## ---- user-facing function --------------------------------------------------

#' Exact Bayesian hybrid index estimation (no MCMC)
#'
#' Replacement for \code{\link{esth}}. The posterior of each test subject's
#' hybrid index is computed exactly by numerical quadrature rather than
#' sampled, so there is no \code{nitt}, \code{burnin} or proposal tuning, and
#' no Monte Carlo error. The prior is Jeffreys' Beta(0.5, 0.5).
#'
#' @param data.prep.object The \code{data.prep} table from \code{data.prep}.
#' @param read.data.precols The \code{precols} object from \code{read.data}.
#' @param test.subject Column(s) identifying hybrid-index units. Default
#'   \code{"INDLABEL"}. Several column names are treated as their combination.
#' @param test.subject.compare As in \code{esth}.
#' @param include.Source Logical. Estimate hybrid indices for parental
#'   reference subjects too. Default \code{TRUE}.
#' @param source.freq How parental allele frequencies are computed when
#'   evaluating parental reference subjects. \code{"leave-one-out"} (default):
#'   a reference subject is evaluated against its own source's frequencies
#'   recomputed without its own allele copies, so its data are not used twice.
#'   \code{"all"}: the full-sample frequencies, as in \code{esth}. Test
#'   subjects are unaffected by this choice. Reference cells whose source has
#'   no other copies at that locus are dropped.
#' @param source.prior Beta pseudo-counts added to the source allele counts
#'   when computing frequencies, (N1 + a) / (N + a + b). Default \code{c(0, 0)}
#'   gives the raw frequencies used by \code{data.prep}. Applies to all
#'   subjects; requires reference rows in the data.
#' @param return.likmeans Logical. Return per-observation posterior likelihood
#'   moments for \code{compare.models}. Default \code{FALSE}.
#' @param likmeans.exclude.Source Drop parental reference rows from
#'   \code{likmeans}. Default: \code{FALSE} with leave-one-out frequencies
#'   (reference rows are then valid observations), \code{TRUE} otherwise.
#' @param fix.subject,fix.value As in \code{esth}.
#' @param locus.info Optional table with columns \code{locus} and
#'   \code{chrom} (or as named by \code{chrom.col}). Required for
#'   \code{loco = TRUE}.
#' @param loco Logical. Also estimate leave-one-chromosome-out hybrid indices:
#'   for each chromosome, the hybrid index from loci on all other
#'   chromosomes. Returned as \code{hi_loco}, for use by \code{ggcline_fast}.
#' @param G Quadrature nodes per subject (default 64).
#' @param chunk.cells Unit-by-locus count cells processed per chunk.
#'
#' @return A list with \code{hi}, \code{test.subject}, optionally
#'   \code{likmeans} and \code{hi_loco}. \code{hi} has the \code{esth}
#'   columns: \code{h_posterior_mode} (mode of the exact posterior),
#'   \code{h_cred_int_lower}/\code{upper} (exact equal-tailed 95\% interval),
#'   \code{beta_mean}, \code{beta_var} (exact posterior mean and variance) and
#'   \code{beta_shape1}, \code{beta_shape2} (Beta moment-matched to the
#'   posterior, for convenience); plus \code{h_posterior_median},
#'   \code{n_loci}, \code{n_allele_copies} and \code{quad_ok}.
#' @export
esth_fast <- function(data.prep.object,
                      read.data.precols,
                      test.subject = "INDLABEL",
                      test.subject.compare = NULL,
                      include.Source = TRUE,
                      source.freq = c("leave-one-out", "all"),
                      source.prior = c(0, 0),
                      return.likmeans = FALSE,
                      likmeans.exclude.Source = NULL,
                      fix.subject = FALSE, fix.value = FALSE,
                      locus.info = NULL, chrom.col = "chrom", loco = FALSE,
                      G = 64L, chunk.cells = 2e5,
                      verbose = TRUE) {

  t_start <- proc.time()
  source.freq <- match.arg(source.freq)
  prior <- c(0.5, 0.5)

  dp <- data.prep.object
  if (!is.data.table(dp)) dp <- as.data.table(dp)
  hasSource <- "Source" %in% names(dp)
  hasRef <- hasSource && any(dp$Source %in% c("S0", "S1"))
  if (!hasRef) source.freq <- "all"
  if (is.null(likmeans.exclude.Source))
    likmeans.exclude.Source <- source.freq == "all"
  if (any(source.prior != 0) && !hasRef)
    stop("source.prior needs parental reference rows in the data.")

  ## ---- multi-column test subjects ----
  ts_cols <- test.subject
  if (length(ts_cols) > 1) {
    test.subject <- paste(ts_cols, collapse = "__")
    dp <- copy(dp)[, (test.subject) := do.call(paste, c(.SD, sep = "__")),
                   .SDcols = ts_cols]
  }
  if (!is.null(test.subject.compare) &&
      uniqueN(dp[[test.subject]]) < uniqueN(dp[[test.subject.compare]])) {
    test.subject.compare <- NULL
    warning("test.subject.compare has higher resolution than test.subject; ignored.")
  }

  dall <- dp[!is.na(Source_allele)]
  d <- if (!include.Source && hasSource) dall[Source == "TEST"] else copy(dall)
  if (!hasSource) d[, Source := "TEST"]

  ## ---- descriptive columns at test-subject resolution (as in esth) ----
  nts <- uniqueN(d[[test.subject]])
  keepcols <- test.subject
  for (pc in setdiff(c(read.data.precols, ts_cols), test.subject)) {
    if (pc %in% names(d) && uniqueN(d[, c(test.subject, pc), with = FALSE]) <= nts)
      keepcols <- c(keepcols, pc)
  }
  if (!is.null(test.subject.compare))
    keepcols <- unique(c(keepcols, test.subject.compare))
  if (hasSource && uniqueN(d[, c("Source", keepcols), with = FALSE]) == nts)
    keepcols <- c("Source", keepcols)
  MET <- unique(d[, keepcols, with = FALSE])
  setkeyv(MET, test.subject)

  ## ---- locus-level source frequencies ----
  ts_levels <- MET[[test.subject]]
  loc_levels <- sort(unique(d$locus))
  L <- length(loc_levels)
  d[, `.u` := match(get(test.subject), ts_levels)]
  d[, `.l` := match(locus, loc_levels)]
  sf <- unique(d[, .(`.l`, S0.prop_1, S1.prop_1)])
  if (anyDuplicated(sf$.l)) stop("Parental allele frequencies differ within a locus.")
  setkey(sf, `.l`)
  S0L <- sf$S0.prop_1; S1L <- sf$S1.prop_1
  if (hasRef) {
    sc <- .source_counts(dall, loc_levels)
    if (any(source.prior != 0)) {
      a <- source.prior[1]; b <- source.prior[2]
      S0L <- (sc$S0$N1 + a) / (sc$S0$N + a + b)
      S1L <- (sc$S1$N1 + a) / (sc$S1$N + a + b)
    }
  }

  ## ---- count cells: one per unit x locus x source ----
  cells <- d[, .(n1 = sum(Source_allele == 1), n0 = sum(Source_allele == 0)),
             keyby = .(ol = `.l`, unit = `.u`, src = Source)]
  cells[, `:=`(S0 = S0L[ol], S1 = S1L[ol])]
  n_dropped <- 0L
  if (source.freq == "leave-one-out") {
    a <- source.prior[1]; b <- source.prior[2]
    for (src in c("S0", "S1")) {
      r <- which(cells$src == src)
      if (!length(r)) next
      N1 <- sc[[src]]$N1[cells$ol[r]] - cells$n1[r]
      N  <- sc[[src]]$N[cells$ol[r]]  - cells$n1[r] - cells$n0[r]
      set(cells, i = r, j = src, value = (N1 + a) / (N + a + b))
    }
    bad <- !is.finite(cells$S0) | !is.finite(cells$S1)
    n_dropped <- sum(bad)
    cells <- cells[!bad]
    if (n_dropped && verbose)
      cat(sprintf("  %d reference cells dropped: no other copies in their source\n",
                  n_dropped))
  }
  cells[, cid := .I]
  ## engine locus index: test cells share their locus; each leave-one-out
  ## reference cell gets its own pseudo-locus carrying its own frequencies
  loo_cell <- source.freq == "leave-one-out" & cells$src %in% c("S0", "S1")
  cells[, loc := ol]
  cells[loo_cell, loc := L + seq_len(sum(loo_cell))]
  S0v <- c(S0L, cells$S0[loo_cell]); Dv <- c(S1L, cells$S1[loo_cell]) - S0v
  U <- length(ts_levels)

  ## ---- fixed subjects ----
  fixed <- rep(FALSE, U); fixval <- rep(NA_real_, U)
  if (isTRUE(fix.subject)) {
    if (length(fix.value) != 1) stop("fix.value must be a single number when fix.subject = TRUE.")
    fixed[] <- TRUE; fixval[] <- fix.value
  } else if (is.character(fix.subject)) {
    if (length(fix.subject) != length(fix.value))
      stop("fix.value must match fix.subject in length and order.")
    mi <- match(fix.subject, ts_levels)
    fixed[mi[!is.na(mi)]] <- TRUE; fixval[mi[!is.na(mi)]] <- fix.value[!is.na(mi)]
  }

  if (verbose)
    cat(sprintf("esth_fast: %d test subjects, %d loci, %d count cells\n",
                U, L, nrow(cells)))

  free_units <- which(!fixed)
  run_engine <- function(cc, want.mom = FALSE) {
    cf <- cc[unit %in% free_units]
    cf[, unit := match(unit, free_units)]
    setkey(cf, loc)
    list(cf = cf,
         eng = .esth_engine(cf, length(free_units), S0v, Dv, prior = prior,
                            G = G, chunk.cells = chunk.cells,
                            want.cellmoments = want.mom))
  }

  ## ---- assemble hi table ----
  cols <- list(h_posterior_mode = rep(NA_real_, U), h_cred_int_lower = rep(NA_real_, U),
               h_cred_int_upper = rep(NA_real_, U), beta_mean = rep(NA_real_, U),
               beta_var = rep(NA_real_, U), h_posterior_median = rep(NA_real_, U),
               quad_ok = rep(NA, U))
  run <- NULL
  if (length(free_units)) {
    run <- run_engine(cells, want.mom = return.likmeans)
    ec <- .eng_cols(run$eng)
    for (nm in names(cols)) cols[[nm]][free_units] <- ec[[nm]]
  }
  cols$h_posterior_mode[fixed] <- fixval[fixed]
  mh <- cols$beta_mean; ab <- mh * (1 - mh) / cols$beta_var - 1

  cnt <- cells[, .(n_loci = uniqueN(ol), n_allele_copies = sum(n1 + n0)), keyby = unit]
  MET[, `:=`(h_posterior_mode = cols$h_posterior_mode,
             h_cred_int_lower = cols$h_cred_int_lower,
             h_cred_int_upper = cols$h_cred_int_upper,
             beta_mean = cols$beta_mean, beta_var = cols$beta_var,
             beta_shape1 = ab * mh, beta_shape2 = ab * (1 - mh))]
  if (!is.null(test.subject.compare))
    MET[, npar_compare := .N, by = test.subject.compare]
  MET[, `:=`(h_posterior_median = cols$h_posterior_median,
             n_loci = cnt$n_loci[match(seq_len(U), cnt$unit)],
             n_allele_copies = cnt$n_allele_copies[match(seq_len(U), cnt$unit)],
             quad_ok = cols$quad_ok)]
  if (any(MET$quad_ok == FALSE, na.rm = TRUE))
    warning(sum(!MET$quad_ok, na.rm = TRUE),
            " test subjects failed the quadrature checks (quad_ok = FALSE).")

  out <- list(hi = MET, test.subject = test.subject, source.freq = source.freq)

  ## ---- leave-one-chromosome-out ----
  if (loco) {
    if (is.null(locus.info)) stop("loco = TRUE needs locus.info with locus and chromosome.")
    li <- as.data.table(locus.info)
    chr <- as.character(li[[chrom.col]][match(loc_levels, li$locus)])
    if (anyNA(chr)) stop("locus.info lacks a chromosome for ",
                         sum(is.na(chr)), " loci.")
    chroms <- sort(unique(chr))
    lo_list <- vector("list", length(chroms))
    for (k in seq_along(chroms)) {
      cc <- cells[chr[ol] != chroms[k]]
      r <- run_engine(cc)
      ec <- .eng_cols(r$eng)
      tab <- data.table(ts = ts_levels, chrom = chroms[k])
      for (nm in names(cols)) {
        v <- rep(NA_real_, U); v[free_units] <- ec[[nm]]; set(tab, j = nm, value = v)
      }
      tab[fixed, h_posterior_mode := fixval[fixed]]
      tab[, quad_ok := as.logical(quad_ok)][, n_loci := cc[, uniqueN(ol), keyby = unit][match(seq_len(U), unit), V1]]
      lo_list[[k]] <- tab
      if (verbose) cat(sprintf("  LOCO %s done\n", chroms[k]))
    }
    hl <- rbindlist(lo_list)
    setnames(hl, c("ts", "chrom"), c(test.subject, chrom.col))
    out$hi_loco <- hl
    out$chrom.col <- chrom.col
    out$locus.chrom <- data.table(locus = loc_levels, chrom = chr)
    setnames(out$locus.chrom, "chrom", chrom.col)
  }

  ## ---- likmeans at allele-copy row level, as esth returns it ----
  if (return.likmeans) {
    mom <- matrix(NA_real_, nrow(cells), 6)
    if (!is.null(run)) mom[run$cf$cid, ] <- run$eng$cellmoments
    if (any(fixed)) {
      fr <- which(fixed[cells$unit])
      A <- cells$S0[fr] + (cells$S1[fr] - cells$S0[fr]) * fixval[cells$unit[fr]]
      mom[fr, ] <- cbind(log(A), log(A)^2, A, log1p(-A), log1p(-A)^2, 1 - A)
    }
    rows <- if (likmeans.exclude.Source) d[Source == "TEST"] else d
    ci <- match(paste(rows$.l, rows$.u, rows$Source),
                paste(cells$ol, cells$unit, cells$src))
    rows <- rows[!is.na(ci)]; ci <- ci[!is.na(ci)]
    is1 <- rows$Source_allele == 1
    lcols <- intersect(unique(c("index", read.data.precols, test.subject,
                                test.subject.compare, "locus", "Source",
                                "Source_allele")), names(rows))
    lm <- rows[, lcols, with = FALSE]
    lm[, postmean.loglik := ifelse(is1, mom[ci, 1], mom[ci, 4])]
    lm[, postmean.loglik.sqrd := ifelse(is1, mom[ci, 2], mom[ci, 5])]
    lm[, postmean.exp.loglik := ifelse(is1, mom[ci, 3], mom[ci, 6])]
    lm[, postvar.loglik := pmax(postmean.loglik.sqrd - postmean.loglik^2, 0)]
    if ("index" %in% names(lm)) setkey(lm, index)
    out$likmeans <- lm
  }

  out$n_reference_cells_dropped <- n_dropped
  out$elapsed <- (proc.time() - t_start)[[3]]
  if (verbose) cat(sprintf("done in %.2f s\n", out$elapsed))
  out
}
