## =============================================================================
## ggcline_fast: chain-free genomic cline estimation
## Part of the gghybrid 3.0.0 _fast function set.
## =============================================================================
##
## Replaces the per-locus Metropolis sampler in ggcline() with:
##   (1) a reparameterised likelihood  p = logistic(v * (logit(h) - c)),
##       c = logit(centre); q = S0 + (S1 - S0) p
##   (2) vectorised Gauss-Newton / Fisher scoring to the joint posterior
##       mode of theta = (log v, logit centre), all loci in lockstep
##   (3) importance sampling from a multivariate t_4 centred at the mode,
##       Pareto-smoothed with loo::psis(), with per-locus Pareto k-hat
##   (4) chunked streaming over loci: peak memory O(N_individuals x chunk)
##
## Scope in this file: unpooled models (each cline parameter free per test
## subject, or fixed). Pooled models use a separate engine (grouping
## interface, to follow).
##
## Dependencies: data.table, loo.
## =============================================================================

## --- weighted quantile and two-sided posterior tail probability -----------

.wq <- function(x, w, p) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  x <- x[ok]; w <- w[ok] / sum(w[ok])
  o <- order(x); cw <- cumsum(w[o])
  i <- which(cw >= p)[1L]
  if (is.na(i)) x[o][length(x)] else x[o][i]
}

.wp <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  x <- x[ok]; w <- w[ok] / sum(w[ok])
  min(1, 2 * min(sum(w[x > 0]), sum(w[x <= 0])))
}


## --- broadcasting helpers --------------------------------------------------
## z (logit hybrid index) is either a length-N vector or an N x L matrix
## (leave-one-chromosome-out); S0 and D are either length-L vectors or N x L
## matrices (leave-one-out source frequencies for reference individuals).
.zv <- function(z, v, N) if (is.matrix(z)) z * rep(v, each = N) else outer(z, v)
.bc <- function(x, N) if (is.matrix(x)) x else rep(x, each = N)

## --- 2x2 symmetric solve, vectorised over loci ------------------------------

.solve2 <- function(a11, a12, a22, b1, b2) {
  det <- a11 * a22 - a12 * a12
  bad <- !is.finite(det) | abs(det) < 1e-300
  det[bad] <- 1
  x1 <- ( a22 * b1 - a12 * b2) / det
  x2 <- (-a12 * b1 + a11 * b2) / det
  x1[bad] <- 0; x2[bad] <- 0
  list(x1 = x1, x2 = x2, det = det, bad = bad)
}


## --- log-likelihood, gradient and expected information ----------------------
## Y, NT : n_ind x n_loc matrices (successes / trials; 0 where missing)
## z     : length n_ind, logit(h), finite
## a, c  : length n_loc, log(v) and logit(centre)

.gc_terms <- function(Y, NT, z, S0, D, a, cc, q.eps, want = c("ll","grad")) {
  v   <- exp(a)
  N   <- nrow(Y)
  eta <- .zv(z, v, N) - rep(v * cc, each = N)
  p   <- plogis(eta)
  q   <- .bc(S0, N) + .bc(D, N) * p
  q   <- pmin(pmax(q, q.eps), 1 - q.eps)

  out <- list()
  if ("ll" %in% want) {
    out$ll <- colSums(Y * log(q) + (NT - Y) * log1p(-q))
  }
  if ("grad" %in% want) {
    dq  <- .bc(D, N) * p * (1 - p)      # dq/deta
    dl  <- Y / q - (NT - Y) / (1 - q)                  # dloglik/dq
    sc  <- dl * dq                                     # dloglik/deta
    out$g_a <- colSums(sc * eta)                       # deta/da = eta
    out$g_c <- -v * colSums(sc)                        # deta/dc = -v

    w <- NT * dq * dq / (q * (1 - q))                  # expected info weight
    s_w  <- colSums(w)
    s_we <- colSums(w * eta)
    s_we2 <- colSums(w * eta * eta)
    out$I_aa <-  s_we2
    out$I_ac <- -v * s_we
    out$I_cc <-  v * v * s_w
    out$s_w  <-  s_w
    out$s_we <-  s_we
  }
  out
}


## --- Gauss-Newton to the joint posterior mode, all loci in lockstep ---------

.gc_mode <- function(Y, NT, z, S0, D, prior.logv, prior.logitcentre,
                     fix.a, fix.c, a.init, c.init,
                     q.eps, max.iter = 60, tol = 1e-8, dec.tol = 1e-10,
                     verbose = FALSE) {

  L <- ncol(Y)
  a <- a.init; cc <- c.init
  pa <- 1 / prior.logv[2]^2          # prior precision, log(v)
  pc <- 1 / prior.logitcentre[2]^2   # prior precision, logit(centre)
  ma <- prior.logv[1]; mc <- prior.logitcentre[1]

  active <- rep(TRUE, L)
  converged <- rep(FALSE, L)

  lp_old <- rep(-Inf, L)

  for (it in seq_len(max.iter)) {
    tr <- .gc_terms(Y, NT, z, S0, D, a, cc, q.eps, want = c("ll","grad"))

    lp <- tr$ll + dnorm(a, ma, prior.logv[2], log = TRUE) +
                  dnorm(cc, mc, prior.logitcentre[2], log = TRUE)

    g_a <- tr$g_a - pa * (a - ma)
    g_c <- tr$g_c - pc * (cc - mc)
    I_aa <- tr$I_aa + pa
    I_cc <- tr$I_cc + pc
    I_ac <- tr$I_ac

    ## drop fixed parameters out of the system
    g_a[fix.a] <- 0; I_ac[fix.a] <- 0; I_aa[fix.a] <- 1
    g_c[fix.c] <- 0; I_ac[fix.c] <- 0; I_cc[fix.c] <- 1

    ## ridge for near-singular blocks (flat loci)
    ridge <- 1e-8 * pmax(1, abs(I_aa) + abs(I_cc))
    st <- .solve2(I_aa + ridge, I_ac, I_cc + ridge, g_a, g_c)

    ## trust region: cap the step length on the latent scale
    len <- sqrt(st$x1^2 + st$x2^2)
    scale <- ifelse(len > 1.5, 1.5 / len, 1)
    da <- st$x1 * scale; dcc <- st$x2 * scale
    da[!active] <- 0; dcc[!active] <- 0

    ## step-halving where the log posterior would drop
    a_new <- a + da; c_new <- cc + dcc
    for (h in 1:6) {
      tr2 <- .gc_terms(Y, NT, z, S0, D, a_new, c_new, q.eps, want = "ll")
      lp_new <- tr2$ll + dnorm(a_new, ma, prior.logv[2], log = TRUE) +
                         dnorm(c_new, mc, prior.logitcentre[2], log = TRUE)
      worse <- is.finite(lp) & (!is.finite(lp_new) | lp_new < lp - 1e-10)
      if (!any(worse)) break
      a_new[worse] <- (a_new[worse] + a[worse]) / 2
      c_new[worse] <- (c_new[worse] + cc[worse]) / 2
    }

    moved <- pmax(abs(a_new - a), abs(c_new - cc))
    ## Newton decrement g' I^-1 g: twice the expected gain in log posterior
    ## from a full step. Scale-free, so it does not stall on flat ridges the
    ## way a parameter-change tolerance can.
    dec <- st$x1 * g_a + st$x2 * g_c
    a <- a_new; cc <- c_new
    active <- moved > tol & !(is.finite(dec) & dec < dec.tol)
    if (verbose) cat(sprintf("  GN iter %2d: %d loci still moving\n",
                             it, sum(active)))
    if (!any(active)) { converged[] <- TRUE; break }
  }
  converged <- !active

  ## final curvature at the mode
  tr <- .gc_terms(Y, NT, z, S0, D, a, cc, q.eps, want = "grad")
  N_eff <- 4 * tr$s_w                 # identifiability flag (see ggcline_fast docs)
  ## information-weighted centroid of logit(h): the point where the data pin
  ## the curve down best; locating the cline relative to it makes the two
  ## parameters nearly orthogonal (as centring a covariate does)
  z0 <- ifelse(tr$s_w > 0, cc + tr$s_we / (exp(a) * tr$s_w), cc)
  z0[!is.finite(z0)] <- cc[!is.finite(z0)]
  I_aa <- tr$I_aa + pa; I_cc <- tr$I_cc + pc; I_ac <- tr$I_ac
  I_aa[fix.a] <- 1e12; I_ac[fix.a] <- 0
  I_cc[fix.c] <- 1e12; I_ac[fix.c] <- 0

  det <- I_aa * I_cc - I_ac^2
  V_aa <-  I_cc / det; V_cc <- I_aa / det; V_ac <- -I_ac / det

  list(a = a, cc = cc, V_aa = V_aa, V_ac = V_ac, V_cc = V_cc,
       iters = it, converged = converged, N_eff = N_eff, z0 = z0)
}


## --- proposal construction ---------------------------------------------------
## A proposal is two 2-d location/Cholesky-scale pairs: q1 on (a, c) and q2 on
## (a, b), b = exp(a) (z0 - c). Lower-triangular scales (l11, l21, l22).

.chol2 <- function(v11, v12, v22) {
  l11 <- sqrt(pmax(v11, 0))
  l21 <- ifelse(l11 > 0, v12 / l11, 0)
  l22 <- sqrt(pmax(v22 - l21^2, 0))
  list(l11 = l11, l21 = l21, l22 = l22)
}

## from the Laplace approximation at the mode (delta method for q2)
.gc_prop_mode <- function(mode, inflate, fix.a, fix.c) {
  L <- length(mode$a)
  k <- .chol2(mode$V_aa * inflate^2, mode$V_ac * inflate^2, mode$V_cc * inflate^2)
  k$l11[fix.a] <- 0; k$l21[fix.a | fix.c] <- 0; k$l22[fix.c] <- 0
  z0 <- if (is.null(mode$z0)) rep(0, L) else mode$z0
  ea <- exp(mode$a); bs <- ea * (z0 - mode$cc)
  ## Cholesky of J Sigma J', J = d(a, b)/d(a, c) = [[1, 0], [b, -v]]
  list(a1 = mode$a, c1 = mode$cc, l11 = k$l11, l21 = k$l21, l22 = k$l22,
       z0 = z0, a2 = mode$a, b2 = bs,
       m11 = k$l11, m21 = bs * k$l11 - ea * k$l21, m22 = ea * k$l22)
}

## from importance-weighted draws (adaptive second pass): weighted means and
## covariances of (a, c) for q1 and of (a, b) for q2
.gc_prop_draws <- function(is_, z0, inflate) {
  W <- is_$W; A <- is_$A; C <- is_$C; B <- exp(A) * (z0[col(A)] - C)
  wm <- function(X) colSums(W * X)
  ma <- wm(A); mc <- wm(C); mb <- wm(B)
  cv <- function(X, mx, Y, my) colSums(W * X * Y) - mx * my
  k1 <- .chol2(cv(A, ma, A, ma) * inflate^2, cv(A, ma, C, mc) * inflate^2,
               cv(C, mc, C, mc) * inflate^2)
  k2 <- .chol2(cv(A, ma, A, ma) * inflate^2, cv(A, ma, B, mb) * inflate^2,
               cv(B, mb, B, mb) * inflate^2)
  list(a1 = ma, c1 = mc, l11 = k1$l11, l21 = k1$l21, l22 = k1$l22,
       z0 = z0, a2 = ma, b2 = mb, m11 = k2$l11, m21 = k2$l21, m22 = k2$l22)
}

## --- importance sampling ----------------------------------------------------

.gc_is <- function(Y, NT, z, S0, D, mode, prior.logv, prior.logitcentre,
                   fix.a, fix.c, S, df, q.eps, inflate,
                   need.likmeans, prop = NULL) {

  N <- nrow(Y); L <- ncol(Y)
  if (is.null(prop)) prop <- .gc_prop_mode(mode, inflate, fix.a, fix.c)
  l11 <- prop$l11; l21 <- prop$l21; l22 <- prop$l22
  m11 <- prop$m11; m21 <- prop$m21; m22 <- prop$m22
  a1 <- prop$a1; c1 <- prop$c1; a2c <- prop$a2; bs <- prop$b2; z0 <- prop$z0

  ## accumulators. Q = log(q) branch (Source_allele == 1), R = log(1-q) branch
  accQ1 <- accQ2 <- accQ3 <- matrix(0, N, L)
  accR1 <- accR2 <- accR3 <- matrix(0, N, L)
  m_a <- m_c <- m_aa <- m_ac <- m_cc <- numeric(L)

  A <- matrix(0, S, L); C <- matrix(0, S, L); LW <- matrix(0, S, L)

  ## ---- pass 1: draw and weight (per-locus log-likelihood only) ----
  ## Defensive mixture proposal, half the draws from each component:
  ##   q1: t_df around the mode in (log v, c), c = logit(centre)
  ##   q2: the same t mapped by the delta method into (log v, b), with
  ##       b = v (z0 - c) and z0 the information-weighted centroid of
  ##       logit(h), then transformed back to c = z0 - b / v.
  ## The data identify the curve best near z0, so (log v, b) are close to
  ## orthogonal; when the centre is an extrapolation away from the data
  ## (shallow clines, or centres near the edge of the sampled hybrid indices)
  ## the posterior of (log v, c) is a curved ridge, which q2 follows and q1
  ## cannot. q1 is better when the centre is well inside the data.
  ## Weights use the full mixture density, so the estimator is never much
  ## worse than the better component. Loci with a fixed parameter use q1.
  both <- !fix.a & !fix.c
  d_free <- (!fix.a) + (!fix.c)
  scale_det <- ifelse(fix.a | fix.c,
                      ifelse(fix.a & fix.c, 1, ifelse(fix.a, l22^2, l11^2)),
                      (l11 * l22)^2)
  lt <- function(y1, y2, ldet, k) lgamma((df + k) / 2) - lgamma(df / 2) -
    (k / 2) * log(df * pi) - 0.5 * ldet - ((df + k) / 2) * log1p((y1^2 + y2^2) / df)

  for (s in seq_len(S)) {
    e1 <- rnorm(L); e2 <- rnorm(L)
    w  <- sqrt(df / rchisq(L, df))
    use2 <- both & (s %% 2L == 0L)
    ## q1 draw
    da <- (l11 * e1) * w
    dc <- (l21 * e1 + l22 * e2) * w
    a_s <- a1 + da; c_s <- c1 + dc
    ## q2 draw
    if (any(use2)) {
      a2 <- a2c + (m11 * e1) * w
      b2 <- bs + (m21 * e1 + m22 * e2) * w
      a_s[use2] <- a2[use2]; c_s[use2] <- (z0 - b2 * exp(-a2))[use2]
      da <- a_s - a1; dc <- c_s - c1
    }
    A[s, ] <- a_s; C[s, ] <- c_s

    ll <- .gc_terms(Y, NT, z, S0, D, a_s, c_s, q.eps, want = "ll")$ll
    lpost <- ll + dnorm(a_s, prior.logv[1], prior.logv[2], log = TRUE) +
                  dnorm(c_s, prior.logitcentre[1], prior.logitcentre[2],
                        log = TRUE)

    ## q1 density (2-d, or 1-d/0-d when parameters are fixed)
    y1 <- ifelse(l11 > 0, da / l11, 0)
    y2 <- ifelse(l22 > 0, (dc - l21 * y1) / l22, 0)
    lq1 <- lt(y1, y2, log(pmax(scale_det, 1e-300)), d_free)
    lq1[d_free == 0] <- 0
    lprop <- lq1
    if (any(both)) {
      ## q2 density at the same point, expressed on (log v, c): times |db/dc| = v
      du <- exp(a_s) * (z0 - c_s) - bs
      z1 <- ifelse(m11 > 0, (a_s - a2c) / m11, 0)
      z2 <- ifelse(m22 > 0, (du - m21 * z1) / m22, 0)
      lq2 <- lt(z1, z2, 2 * log(pmax(m11 * m22, 1e-300)), 2) + a_s
      mx <- pmax(lq1, lq2)
      lmix <- mx + log(0.5 * exp(lq1 - mx) + 0.5 * exp(lq2 - mx))
      lprop[both] <- lmix[both]
    }
    LW[s, ] <- lpost - lprop
  }

  LWraw <- LW
  ## ---- PSIS per locus (loo::psis, one column per locus) ----
  free <- !(fix.a & fix.c)
  khat <- rep(NA_real_, L)
  W <- matrix(1 / S, S, L)
  if (any(free)) {
    ps <- suppressWarnings(loo::psis(LW[, free, drop = FALSE],
                                     r_eff = rep(1, sum(free))))
    W[, free] <- weights(ps, log = FALSE, normalize = TRUE)
    khat[free] <- loo::pareto_k_values(ps)
  }
  W[!is.finite(W)] <- 0
  ess <- 1 / colSums(W^2)

  ## ---- pass 2: accumulate weighted moments ----
  for (s in seq_len(S)) {
    w <- W[s, ]
    a_s <- A[s, ]; c_s <- C[s, ]
    m_a  <- m_a  + w * a_s
    m_c  <- m_c  + w * c_s
    m_aa <- m_aa + w * a_s * a_s
    m_ac <- m_ac + w * a_s * c_s
    m_cc <- m_cc + w * c_s * c_s

    if (need.likmeans) {
      v <- exp(a_s)
      eta <- .zv(z, v, N) - rep(v * c_s, each = N)
      p <- plogis(eta)
      q <- .bc(S0, N) + .bc(D, N) * p
      q <- pmin(pmax(q, q.eps), 1 - q.eps)
      lq <- log(q); lr <- log1p(-q)
      wm <- rep(w, each = N)
      accQ1 <- accQ1 + wm * lq
      accQ2 <- accQ2 + wm * lq * lq
      accQ3 <- accQ3 + wm * q
      accR1 <- accR1 + wm * lr
      accR2 <- accR2 + wm * lr * lr
      accR3 <- accR3 + wm * (1 - q)
    }
  }

  var_a <- pmax(m_aa - m_a^2, 0)
  var_c <- pmax(m_cc - m_c^2, 0)
  cov_ac <- m_ac - m_a * m_c

  list(mean_a = m_a, mean_c = m_c, var_a = var_a, var_c = var_c,
       cov_ac = cov_ac, khat = khat, ess = ess,
       A = A, C = C, W = W, LWraw = LWraw,
       accQ1 = accQ1, accQ2 = accQ2, accQ3 = accQ3,
       accR1 = accR1, accR2 = accR2, accR3 = accR3)
}



## ---------------------------------------------------------------------------
#' Genomic cline estimation without MCMC
#'
#' Alternative to \code{\link{ggcline}} for the unpooled case. Returns an
#' object with the same \code{$gc} and \code{$likmeans} structure, so
#' \code{compare.models}, \code{calc_AIC} and \code{plot_clinecurve} continue
#' to work.
#'
#' @param data.prep.object The \code{data.prep} table.
#' @param esth.object Output of \code{esth} or \code{esth_fast} (or any list
#'   with \code{$hi} and \code{$test.subject}).
#' @param esth.colname Column of \code{esth.object$hi} used as the hybrid index.
#' @param test.subject Column(s) defining cline test subjects; several
#'   column names are treated as their combination. Default \code{"locus"}.
#' @param include.Source Use parental reference individuals in estimation.
#' @param return.likmeans Return per-observation posterior likelihood moments.
#' @param likmeans.exclude.Source Drop parental rows from \code{likmeans}.
#'   Default: \code{FALSE} when reference rows are used with leave-one-out
#'   frequencies (they are then valid observations), otherwise \code{TRUE}.
#' @param source.freq With \code{include.Source = TRUE}: \code{"leave-one-out"}
#'   (default) evaluates each parental reference individual (hybrid-index unit)
#'   against its own source's allele frequencies recomputed without its own
#'   allele copies, so its data are not used twice; \code{"all"} uses the
#'   full-sample frequencies, as \code{ggcline} does. Use the same setting as
#'   in \code{esth_fast}.
#' @param source.prior Beta pseudo-counts added to source allele counts,
#'   (N1 + a) / (N + a + b). Default \code{c(0, 0)}: raw frequencies.
#' @param loco Use leave-one-chromosome-out hybrid indices: for each locus,
#'   the hybrid index estimated without that locus's chromosome. Requires an
#'   \code{esth_fast} object run with \code{loco = TRUE}.
#' @param fix.subject.v,fix.value.v,fix.subject.centre,fix.value.centre As in
#'   \code{ggcline} (values on the data scale).
#' @param prior.logitcentre,prior.logv Normal priors (mean, sd) on the latent
#'   scale, as in \code{ggcline}.
#' @param S Importance draws per test subject (300-1000 is usually plenty).
#' @param df,inflate Degrees of freedom and scale inflation of the t proposal.
#' @param ci.method \code{"quantile"} (default, weighted quantiles of the
#'   draws) or \code{"normal"} (latent-scale normal approximation as in
#'   \code{ggcline}).
#' @param chunk.size Test subjects held in memory at once.
#' @param q.eps Floor on fitted genotype probability (replaces the
#'   \code{loglik := -1000} clamp in \code{ggcline}).
#' @param adapt Run an adaptive second importance-sampling pass for test
#'   subjects whose first-pass posterior moments disagree with the Laplace
#'   approximation (weakly informative loci with curved posteriors).
#'   Reported in \code{is_adapted}. Default \code{TRUE}.
#' @param h.eps Hybrid index clamped to \code{[h.eps, 1 - h.eps]} before the
#'   logit, so parental individuals give finite values.
#'
#' @return List with \code{gc}, \code{test.subject}, optionally
#'   \code{likmeans}, and \code{elapsed}. \code{gc} has the \code{ggcline}
#'   columns plus \code{khat} (Pareto k; values above 0.7 mean the importance
#'   sampler is unreliable for that subject), \code{ess_is} (importance
#'   effective sample size), \code{converged} (Gauss-Newton), and \code{N_eff},
#'   an identifiability measure: the Fisher information for the cline
#'   expressed as the equivalent number of allele copies at the centre of a
#'   fixed-difference marker, 4 * sum(n D^2 p^2 (1-p)^2 / (q (1-q))) at the
#'   posterior mode. Small \code{N_eff} means little information, whatever the
#'   cline shape.
#' @export
ggcline_fast <- function(data.prep.object,
                         esth.object,
                         esth.colname = "h_posterior_mode",
                         test.subject = "locus",
                         include.Source = FALSE,
                         return.likmeans = FALSE,
                         likmeans.exclude.Source = NULL,
                         read.data.precols = NULL,
                         source.freq = c("leave-one-out", "all"),
                         source.prior = c(0, 0),
                         loco = FALSE,
                         fix.subject.v = FALSE, fix.value.v = NULL,
                         fix.subject.centre = FALSE, fix.value.centre = NULL,
                         prior.logitcentre = c(0, sqrt(50)),
                         prior.logv = c(0, sqrt(10)),
                         S = 500, df = 4, inflate = 1.2,
                         ci.method = c("quantile", "normal"),
                         chunk.size = 20000L,
                         q.eps = 1e-10, h.eps = 1e-6, adapt = TRUE,
                         seed = NULL, verbose = TRUE) {

  ci.method <- match.arg(ci.method)
  source.freq <- match.arg(source.freq)
  if (!is.null(seed)) set.seed(seed)
  t_start <- proc.time()

  ts.esth <- esth.object$test.subject
  hi <- as.data.table(esth.object$hi)
  dp <- data.prep.object
  if (!is.data.table(dp)) dp <- as.data.table(dp)

  ## ---- multi-column test subjects ----
  ts_cols <- test.subject
  if (length(ts_cols) > 1) {
    test.subject <- paste(ts_cols, collapse = "__")
    dp <- copy(dp)[, (test.subject) := do.call(paste, c(.SD, sep = "__")),
                   .SDcols = ts_cols]
  }
  if (!test.subject %in% names(dp))
    stop("test.subject must be a column (or columns) of data.prep.object")
  if (!esth.colname %in% names(hi))
    stop("esth.colname not found in esth.object$hi")

  ## ---- join hybrid index, subset ----
  d <- merge(dp, hi[, c(ts.esth, esth.colname), with = FALSE],
             by = ts.esth, all.x = FALSE)
  setnames(d, esth.colname, ".h")
  if (!include.Source && "Source" %in% names(d)) d <- d[Source == "TEST"]
  d <- d[!is.na(Source_allele) & !is.na(.h)]

  ## ---- integer keys ----
  ts_levels <- sort(unique(d[[test.subject]]))
  d[, .ts := match(get(test.subject), ts_levels)]
  ind_levels <- sort(unique(d[[ts.esth]]))
  d[, .ind := match(get(ts.esth), ind_levels)]

  hvals <- d[, .(h = .h[1]), keyby = .ind]$h
  z_all <- qlogis(pmin(pmax(hvals, h.eps), 1 - h.eps))
  N <- length(z_all)
  L <- length(ts_levels)

  if (verbose)
    cat(sprintf("ggcline_fast: %d test subjects, %d hybrid-index units, %d rows\n",
                L, N, nrow(d)))

  sf <- d[, .(S0 = S0.prop_1[1], S1 = S1.prop_1[1],
              nfreq = uniqueN(paste(S0.prop_1, S1.prop_1))), keyby = .ts]
  if (any(sf$nfreq > 1))
    stop("Parental allele frequencies differ within a test subject; ",
         "each test subject must correspond to a single locus.")

  ## ---- per-individual source frequencies and hybrid indices ----
  ts_locus <- d[, .(locus = locus[1], nl = uniqueN(locus)), keyby = .ts]
  hasRef <- "Source" %in% names(d) && any(d$Source %in% c("S0", "S1"))
  use_loo <- source.freq == "leave-one-out" && hasRef
  if (is.null(likmeans.exclude.Source)) likmeans.exclude.Source <- !use_loo
  if ((use_loo || any(source.prior != 0)) && any(ts_locus$nl > 1))
    stop("leave-one-out or source.prior frequencies need one locus per test subject.")
  if (use_loo || any(source.prior != 0)) {
    ref <- dp[!is.na(Source_allele) & Source %in% c("S0", "S1")]
    if (!nrow(ref)) stop("source frequencies need parental reference rows in data.prep.object")
    sc <- ref[, .(N1 = sum(Source_allele == 1), N = .N), keyby = .(Source, locus)]
    getc <- function(src, col) {
      g <- sc[Source == src]; v <- g[[col]][match(ts_locus$locus, g$locus)]
      ifelse(is.na(v), 0, v) }
    cnt <- list(S0 = list(N1 = getc("S0", "N1"), N = getc("S0", "N")),
                S1 = list(N1 = getc("S1", "N1"), N = getc("S1", "N")))
    pa <- source.prior[1]; pb <- source.prior[2]
    if (any(source.prior != 0)) {
      sf[, S0 := (cnt$S0$N1 + pa) / (cnt$S0$N + pa + pb)]
      sf[, S1 := (cnt$S1$N1 + pa) / (cnt$S1$N + pa + pb)]
    }
  }
  if (use_loo) {
    if (d[Source != "TEST", uniqueN(Source), by = .ind][, any(V1 > 1)])
      stop("leave-one-out frequencies need each hybrid-index unit to belong to one source")
    own <- d[Source %in% c("S0", "S1"),
             .(n1 = sum(Source_allele == 1), n = .N), keyby = .(.ind, .ts, Source)]
    own[, f := {
      N1 <- ifelse(Source == "S0", cnt$S0$N1[.ts], cnt$S1$N1[.ts])
      Nn <- ifelse(Source == "S0", cnt$S0$N[.ts],  cnt$S1$N[.ts])
      (N1 - n1 + source.prior[1]) / (Nn - n + sum(source.prior)) }]
    if (verbose && any(!is.finite(own$f)))
      cat(sprintf("  %d reference cells dropped: no other copies in their source\n",
                  sum(!is.finite(own$f))))
    setkey(own, .ts)
  }
  if (loco) {
    hl <- esth.object$hi_loco; lc <- esth.object$locus.chrom
    ccol <- esth.object$chrom.col
    if (is.null(hl)) stop("loco = TRUE needs an esth_fast object run with loco = TRUE")
    chr_ts <- as.character(lc[[ccol]][match(ts_locus$locus, lc$locus)])
    if (anyNA(chr_ts)) stop("no chromosome for some loci in esth.object$locus.chrom")
    chroms <- sort(unique(as.character(hl[[ccol]])))
    HZ <- matrix(NA_real_, N, length(chroms))
    ri <- match(hl[[ts.esth]], ind_levels); ok <- !is.na(ri)
    HZ[cbind(ri[ok], match(as.character(hl[[ccol]][ok]), chroms))] <- hl[[esth.colname]][ok]
    HZ <- qlogis(pmin(pmax(HZ, h.eps), 1 - h.eps))
    chr_idx <- match(chr_ts, chroms)
  }

  ## ---- fixed-parameter handling ----
  fixa <- rep(FALSE, L); fixc <- rep(FALSE, L)
  a_fix <- rep(NA_real_, L); c_fix <- rep(NA_real_, L)
  if (!identical(fix.subject.v, FALSE)) {
    idx <- if (isTRUE(fix.subject.v)) seq_len(L) else
             match(as.character(fix.subject.v), ts_levels)
    vals <- rep_len(fix.value.v, length(idx))
    keep <- !is.na(idx); idx <- idx[keep]
    fixa[idx] <- TRUE; a_fix[idx] <- log(vals[keep])
  }
  if (!identical(fix.subject.centre, FALSE)) {
    idx <- if (isTRUE(fix.subject.centre)) seq_len(L) else
             match(as.character(fix.subject.centre), ts_levels)
    vals <- rep_len(fix.value.centre, length(idx))
    keep <- !is.na(idx); idx <- idx[keep]
    fixc[idx] <- TRUE; c_fix[idx] <- qlogis(vals[keep])
  }
  npar <- (!fixa) + (!fixc)

  ## ---- results containers ----
  res <- data.table(.ts = seq_len(L),
                    mean_a = NA_real_, var_a = NA_real_,
                    mean_c = NA_real_, var_c = NA_real_, cov_ac = NA_real_,
                    a_lo = NA_real_, a_hi = NA_real_, a_p = NA_real_,
                    c_lo = NA_real_, c_hi = NA_real_, c_p = NA_real_,
                    khat = NA_real_, ess = NA_real_, converged = NA,
                    N_eff = NA_real_, adapted = NA)
  lmlist <- if (return.likmeans) list() else NULL

  ## ---- chunk over test subjects ----
  chunks <- split(seq_len(L), ceiling(seq_len(L) / chunk.size))
  setkey(d, .ts)

  for (ci in seq_along(chunks)) {
    jj <- chunks[[ci]]
    sub <- d[.(jj)]
    cmap <- match(sub$.ts, jj)
    Lc <- length(jj)

    ## dense binomial counts; missing combinations stay at zero
    lin <- (cmap - 1L) * N + sub$.ind
    NT <- matrix(tabulate(lin, nbins = N * Lc), N, Lc)
    Y  <- matrix(tabulate(lin[sub$Source_allele == 1L], nbins = N * Lc), N, Lc)

    S0c <- sf$S0[jj]; Dc <- sf$S1[jj] - S0c
    Zc <- z_all
    drop <- NULL
    if (use_loo) {
      o <- own[.(jj), nomatch = NULL]
      if (nrow(o)) {
        S1c <- sf$S1[jj]
        S0c <- matrix(S0c, N, Lc, byrow = TRUE); S1c <- matrix(S1c, N, Lc, byrow = TRUE)
        pos <- cbind(o$.ind, match(o$.ts, jj))
        is0 <- o$Source == "S0"
        S0c[pos[is0, , drop = FALSE]] <- o$f[is0]
        S1c[pos[!is0, , drop = FALSE]] <- o$f[!is0]
        Dc <- S1c - S0c
        drop <- pos[!is.finite(o$f), , drop = FALSE]
      }
    }
    if (loco) {
      Zc <- HZ[, chr_idx[jj], drop = FALSE]
      drop <- rbind(drop, which(is.na(Zc), arr.ind = TRUE))
      Zc[is.na(Zc)] <- 0
    }
    if (length(drop) && nrow(drop)) {
      NT[drop] <- 0; Y[drop] <- 0
      if (is.matrix(S0c)) { S0c[drop] <- 0.5; Dc[drop] <- 0 }
    }
    dropped_lin <- if (length(drop) && nrow(drop)) (drop[, 2] - 1L) * N + drop[, 1] else integer(0)

    ## starting values: v = 1, centre at the mean logit(h) of allele-1 copies
    a0 <- rep(0, Lc)
    c0 <- colSums(Y * Zc) / pmax(colSums(Y), 1)
    c0[!is.finite(c0)] <- 0
    c0 <- pmin(pmax(c0, -8), 8)
    a0[fixa[jj]] <- a_fix[jj][fixa[jj]]
    c0[fixc[jj]] <- c_fix[jj][fixc[jj]]

    md <- .gc_mode(Y, NT, Zc, S0c, Dc, prior.logv, prior.logitcentre,
                   fixa[jj], fixc[jj], a0, c0, q.eps)
    md$a[fixa[jj]]  <- a_fix[jj][fixa[jj]]
    md$cc[fixc[jj]] <- c_fix[jj][fixc[jj]]

    is_ <- .gc_is(Y, NT, Zc, S0c, Dc, md, prior.logv, prior.logitcentre,
                  fixa[jj], fixc[jj], S, df, q.eps, inflate,
                  need.likmeans = return.likmeans)

    ## ---- adaptive second pass where the Laplace proposal was poor ----
    ## Weak-information loci can have curved or skewed posteriors that the
    ## Laplace approximation under-covers. Where the first-pass weighted
    ## moments disagree with it, refit both proposal components to those
    ## moments and redraw.
    both <- !fixa[jj] & !fixc[jj]
    rat_a <- sqrt(is_$var_a / md$V_aa); rat_c <- sqrt(is_$var_c / md$V_cc)
    redo <- both & (!md$converged | !is.finite(rat_a) | !is.finite(rat_c) |
                    abs(log(rat_a)) > log(1.15) | abs(log(rat_c)) > log(1.15) |
                    is_$ess < 0.5 * S | (is.finite(is_$khat) & is_$khat > 0.5))
    adapted <- rep(FALSE, Lc)
    if (adapt && any(redo)) {
      k <- which(redo)
      colk <- function(x) if (is.matrix(x)) x[, k, drop = FALSE] else x
      veck <- function(x) if (is.matrix(x)) x[, k, drop = FALSE] else x[k]
      md_k <- lapply(md, function(x) if (length(x) == Lc) x[k] else x)
      prop <- .gc_prop_draws(list(W = is_$W[, k, drop = FALSE], A = is_$A[, k, drop = FALSE],
                                  C = is_$C[, k, drop = FALSE]), md_k$z0, inflate)
      ## never narrower than the Laplace proposal in log v
      prop$l11 <- pmax(prop$l11, sqrt(md_k$V_aa) * inflate)
      prop$m11 <- prop$l11
      is2 <- .gc_is(Y[, k, drop = FALSE], NT[, k, drop = FALSE], colk(Zc),
                    veck(S0c), veck(Dc), md_k, prior.logv, prior.logitcentre,
                    fixa[jj][k], fixc[jj][k], S, df, q.eps, inflate,
                    need.likmeans = return.likmeans, prop = prop)
      for (nm in names(is2)) {
        x <- is2[[nm]]
        if (is.matrix(x)) is_[[nm]][, k] <- x else if (length(x) == length(k)) is_[[nm]][k] <- x
      }
      adapted[k] <- TRUE
    }

    ## intervals and p-values
    if (ci.method == "quantile") {
      a_lo <- a_hi <- a_p <- c_lo <- c_hi <- c_p <- numeric(Lc)
      for (m in seq_len(Lc)) {
        a_lo[m] <- .wq(is_$A[, m], is_$W[, m], 0.025)
        a_hi[m] <- .wq(is_$A[, m], is_$W[, m], 0.975)
        a_p[m]  <- .wp(is_$A[, m], is_$W[, m])
        c_lo[m] <- .wq(is_$C[, m], is_$W[, m], 0.025)
        c_hi[m] <- .wq(is_$C[, m], is_$W[, m], 0.975)
        c_p[m]  <- .wp(is_$C[, m], is_$W[, m])
      }
    } else {
      sda <- sqrt(is_$var_a); sdc <- sqrt(is_$var_c)
      a_lo <- qnorm(0.025, is_$mean_a, sda); a_hi <- qnorm(0.975, is_$mean_a, sda)
      c_lo <- qnorm(0.025, is_$mean_c, sdc); c_hi <- qnorm(0.975, is_$mean_c, sdc)
      a_p <- 2 * pnorm(0, is_$mean_a, sda, lower.tail = is_$mean_a > 0)
      c_p <- 2 * pnorm(0, is_$mean_c, sdc, lower.tail = is_$mean_c > 0)
    }

    set(res, i = jj, j = "mean_a", value = is_$mean_a)
    set(res, i = jj, j = "var_a",  value = is_$var_a)
    set(res, i = jj, j = "mean_c", value = is_$mean_c)
    set(res, i = jj, j = "var_c",  value = is_$var_c)
    set(res, i = jj, j = "cov_ac", value = is_$cov_ac)
    set(res, i = jj, j = "a_lo", value = a_lo); set(res, i = jj, j = "a_hi", value = a_hi)
    set(res, i = jj, j = "c_lo", value = c_lo); set(res, i = jj, j = "c_hi", value = c_hi)
    set(res, i = jj, j = "a_p", value = pmin(a_p, 1))
    set(res, i = jj, j = "c_p", value = pmin(c_p, 1))
    set(res, i = jj, j = "khat", value = is_$khat)
    set(res, i = jj, j = "ess",  value = is_$ess)
    set(res, i = jj, j = "converged", value = md$converged)
    set(res, i = jj, j = "N_eff", value = md$N_eff)
    set(res, i = jj, j = "adapted", value = adapted)

    ## ---- reduce likmeans for this chunk, then discard the matrices ----
    if (return.likmeans) {
      keep <- if (likmeans.exclude.Source && "Source" %in% names(sub))
                sub$Source == "TEST" else rep(TRUE, nrow(sub))
      keep <- keep & !(lin %in% dropped_lin)
      s1 <- sub$Source_allele == 1L
      lm <- data.table(index = sub$index)
      if (!is.null(read.data.precols))
        for (pc in intersect(read.data.precols, names(sub))) set(lm, j = pc, value = sub[[pc]])
      set(lm, j = test.subject, value = sub[[test.subject]])
      if (test.subject != "locus") set(lm, j = "locus", value = sub$locus)
      if ("Source" %in% names(sub)) set(lm, j = "Source", value = sub$Source)
      set(lm, j = "Source_allele", value = sub$Source_allele)
      lm[, postmean.loglik := ifelse(s1, is_$accQ1[lin], is_$accR1[lin])]
      lm[, postmean.loglik.sqrd := ifelse(s1, is_$accQ2[lin], is_$accR2[lin])]
      lm[, postmean.exp.loglik := ifelse(s1, is_$accQ3[lin], is_$accR3[lin])]
      lm[, postvar.loglik := pmax(postmean.loglik.sqrd - postmean.loglik^2, 0)]
      lmlist[[length(lmlist) + 1L]] <- lm[keep]
    }

    rm(Y, NT, is_, md)
    if (verbose && length(chunks) > 1)
      cat(sprintf("  chunk %d/%d done\n", ci, length(chunks)))
  }

  ## ---- assemble output in ggcline's format ----
  gcout <- data.table(V1 = ts_levels,
                      exp_mean_log_v = exp(res$mean_a),
                      v_lower_95 = exp(res$a_lo),
                      v_upper_95 = exp(res$a_hi),
                      v_pvalue = res$a_p,
                      invlogit_mean_logit_centre = plogis(res$mean_c),
                      centre_lower_95 = plogis(res$c_lo),
                      centre_upper_95 = plogis(res$c_hi),
                      centre_pvalue = res$c_p,
                      mean_log_v = res$mean_a,
                      var_log_v = res$var_a,
                      mean_logit_centre = res$mean_c,
                      var_logit_centre = res$var_c,
                      cov_log_v_logit_centre = res$cov_ac,
                      npar = npar,
                      sum_npar = sum(npar),
                      khat = res$khat,
                      ess_is = res$ess,
                      converged = res$converged,
                      N_eff = res$N_eff,
                      is_adapted = res$adapted)
  setnames(gcout, "V1", test.subject)
  gcout[fixa, c("v_lower_95", "v_upper_95", "v_pvalue") := NA]
  gcout[fixc, c("centre_lower_95", "centre_upper_95", "centre_pvalue") := NA]

  if (test.subject == "locus") {
    gcout[, S0.prop_1 := sf$S0][, S1.prop_1 := sf$S1]
    setcolorder(gcout, c("locus", "S0.prop_1", "S1.prop_1"))
  }
  if (length(ts_cols) > 1) {
    parts <- tstrsplit(gcout[[test.subject]], "__", fixed = TRUE)
    for (k in seq_along(ts_cols)) set(gcout, j = ts_cols[k], value = parts[[k]])
  }

  out <- list(gc = gcout, test.subject = test.subject,
              source.freq = if (use_loo) "leave-one-out" else "all", loco = loco)
  if (return.likmeans) {
    out$likmeans <- rbindlist(lmlist)
    setkey(out$likmeans, index)
  }

  el <- (proc.time() - t_start)[[3]]
  if (verbose) {
    nbad <- sum(gcout$khat > 0.7, na.rm = TRUE)
    cat(sprintf("done in %.2f s. %d/%d test subjects with Pareto k > 0.7%s\n",
                el, nbad, L, if (nbad) " (raise S or inflate)" else ""))
  }
  out$elapsed <- el
  out
}
