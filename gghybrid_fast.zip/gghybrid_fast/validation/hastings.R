## Target Beta(2, 80) (mean 0.0244). MH with truncated-normal proposal on [0,1],
## exactly as in esth, with and without the Hastings correction.
suppressMessages(library(truncnorm)); set.seed(42)
a <- 2; b <- 80; sdp <- 0.02; n <- 4e5
run <- function(hastings) {
  x <- 0.02; out <- numeric(n)
  for (i in 1:n) {
    y <- rtruncnorm(1, 0, 1, x, sdp)
    lr <- dbeta(y, a, b, log = TRUE) - dbeta(x, a, b, log = TRUE)
    if (hastings) lr <- lr + log(dtruncnorm(x, 0, 1, y, sdp)) - log(dtruncnorm(y, 0, 1, x, sdp))
    if (log(runif(1)) < lr) x <- y
    out[i] <- x
  }
  out[-(1:5e4)]
}
x0 <- run(FALSE); x1 <- run(TRUE)
sdt <- sqrt(a*b/((a+b)^2*(a+b+1)))
cat(sprintf("true mean %.5f sd %.5f\n", a/(a+b), sdt))
cat(sprintf("esth-style (no Hastings): mean %.5f (bias %+.3f SD), sd %.5f (ratio %.3f)\n", mean(x0), (mean(x0)-a/(a+b))/sdt, sd(x0), sd(x0)/sdt))
cat(sprintf("with Hastings correction: mean %.5f (bias %+.3f SD), sd %.5f (ratio %.3f)\n", mean(x1), (mean(x1)-a/(a+b))/sdt, sd(x1), sd(x1)/sdt))
