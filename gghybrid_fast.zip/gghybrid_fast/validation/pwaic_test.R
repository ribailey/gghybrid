.libPaths(c("/home/claude/rlib", .libPaths()))
suppressPackageStartupMessages({library(gghybrid); library(data.table)})
s <- readRDS("prep.rds"); hind <- readRDS("esth_ref.rds")$hind
dp <- s$prep$data.prep
set.seed(3); keep <- sort(sample(unique(dp$locus), 12))
dps <- dp[locus %in% keep]
ggcline_patched <- NULL
eval(parse("ggcline_patched.R")); environment(ggcline_patched) <- asNamespace("gghybrid")
run <- function(f, seed) { set.seed(seed); t0 <- proc.time()
  r <- f(data.prep.object = copy(dps), esth.object = hind, include.Source = TRUE,
         return.likmeans = TRUE, read.data.precols = s$dat$precols,
         nitt = 3000, burnin = 1000, print.k = 1e9)
  list(r = r, t = (proc.time() - t0)[3]) }
orig <- run(ggcline, 11); saveRDS(orig, "gc_orig12.rds"); cat("orig done", orig$t, "\n")
pat  <- run(ggcline_patched, 11); saveRDS(pat, "gc_pat12.rds"); cat("patched done", pat$t, "\n")
