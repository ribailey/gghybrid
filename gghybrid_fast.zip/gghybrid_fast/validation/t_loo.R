.libPaths(c("/home/claude/rlib", .libPaths()))
suppressPackageStartupMessages({library(data.table)})
source("/mnt/user-data/outputs/gghybrid_fast/R/esth_fast.R"); source("brute.R")
s <- readRDS("prep.rds"); dp <- s$prep$data.prep; pc <- s$dat$precols
all <- esth_fast(dp, pc, source.freq = "all", verbose = FALSE)
loo <- esth_fast(dp, pc, return.likmeans = TRUE)
m <- merge(all$hi, loo$hi, by = c("INDLABEL", "Source", "POPID"), suffixes = c(".all", ".loo"))
cat("TEST individuals identical:", m[Source == "TEST", isTRUE(all.equal(h_posterior_mode.all, h_posterior_mode.loo)) &&
    isTRUE(all.equal(beta_var.all, beta_var.loo))], "\n")
print(m[Source != "TEST", .(n = .N,
   mean_all = mean(beta_mean.all), mean_loo = mean(beta_mean.loo),
   ciw_all = mean(h_cred_int_upper.all - h_cred_int_lower.all),
   ciw_loo = mean(h_cred_int_upper.loo - h_cred_int_lower.loo),
   max_shift_sd = max(abs(beta_mean.loo - beta_mean.all) / sqrt(beta_var.loo))), by = Source])
print(m[Source == "S1", .(INDLABEL, mode_all = h_posterior_mode.all, mode_loo = h_posterior_mode.loo,
   lo_loo = h_cred_int_lower.loo, hi_loo = h_cred_int_upper.loo)])
## brute-force check of the leave-one-out posteriors: rewrite frequencies per row
dl <- copy(dp[!is.na(Source_allele)])
cnt <- dl[Source != "TEST", .(N1 = sum(Source_allele == 1), N = .N), by = .(Source, locus)]
own <- dl[Source != "TEST", .(n1 = sum(Source_allele == 1), n = .N), by = .(INDLABEL, Source, locus)]
own <- merge(own, cnt, by = c("Source", "locus"))[, f := (N1 - n1) / (N - n)]
dl <- merge(dl, own[, .(INDLABEL, locus, f)], by = c("INDLABEL", "locus"), all.x = TRUE)
dl[Source == "S0", S0.prop_1 := f]; dl[Source == "S1", S1.prop_1 := f]
dl <- dl[is.finite(S0.prop_1) & is.finite(S1.prop_1)]
br <- brute_hi(dl[Source != "TEST"])
mb <- merge(loo$hi, br, by = "INDLABEL")
cat(sprintf("LOO vs brute (%d reference inds): max|mean d|/sd %.1e  max|q2.5 d|/sd %.1e  max|q97.5 d|/sd %.1e  max|mode d|/sd %.1e\n",
  nrow(mb), max(abs(mb$beta_mean - mb$b_mean)/sqrt(mb$b_var)), max(abs(mb$h_cred_int_lower - mb$b_lo)/sqrt(mb$b_var)),
  max(abs(mb$h_cred_int_upper - mb$b_hi)/sqrt(mb$b_var)), max(abs(mb$h_posterior_mode - mb$b_mode)/sqrt(mb$b_var))))
cat("likmeans rows by Source:", paste(capture.output(print(loo$likmeans[, .N, by = Source])), collapse = " "), "\n")
## LOCO
chr <- fread("/home/claude/gghybrid/markerchr.csv"); setnames(chr, 1, "locus")
lc <- esth_fast(dp, pc, locus.info = chr, loco = TRUE, verbose = FALSE)
cat(sprintf("LOCO: %d rows, %d chromosomes, %.2f s total\n", nrow(lc$hi_loco), uniqueN(lc$hi_loco$chrom), lc$elapsed))
x <- merge(lc$hi_loco, lc$hi[, .(INDLABEL, h_full = h_posterior_mode, sd_full = sqrt(beta_var))], by = "INDLABEL")
print(x[, .(n_loci = median(n_loci), max_shift_in_sd = max(abs(h_posterior_mode - h_full)/sd_full)), by = chrom][order(-n_loci)])
print(table(lc$hi_loco$quad_ok))
saveRDS(list(loo = loo, all = all, loco = lc), "esth_fast_loo.rds")
