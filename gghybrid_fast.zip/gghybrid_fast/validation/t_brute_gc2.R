.libPaths(c("/home/claude/rlib", .libPaths()))
suppressPackageStartupMessages({library(data.table)})
source("/mnt/user-data/outputs/gghybrid_fast/R/esth_fast.R"); source("/mnt/user-data/outputs/gghybrid_fast/R/ggcline_fast.R")
s <- readRDS("prep.rds"); dp <- s$prep$data.prep; pc <- s$dat$precols
chr <- fread("/home/claude/gghybrid/markerchr.csv"); setnames(chr, 1, "locus")
he <- esth_fast(dp, pc, locus.info = chr, loco = TRUE, verbose = FALSE)
ind_h <- he$hi_loco[, .(INDLABEL, chrom, h = pmin(pmax(h_posterior_mode, 1e-6), 1 - 1e-6))]
cnt <- dp[!is.na(Source_allele) & Source != "TEST", .(N1 = sum(Source_allele == 1), N = .N), by = .(Source, locus)]
own <- dp[!is.na(Source_allele) & Source != "TEST", .(n1 = sum(Source_allele == 1), n = .N), by = .(INDLABEL, Source, locus)]
brute <- function(lcs, ar = c(-4, 7), cr = c(-8, 8), n = 400) {
  r <- dp[locus == lcs & !is.na(Source_allele)]; r[, chrom := chr$chrom[match(lcs, chr$locus)]]
  r <- merge(merge(r, ind_h, by = c("INDLABEL", "chrom")), own[locus == lcs, .(INDLABEL, n1, n)], by = "INDLABEL", all.x = TRUE)
  r[, S0 := S0.prop_1][, S1 := S1.prop_1]
  c0 <- cnt[locus == lcs & Source == "S0"]; c1 <- cnt[locus == lcs & Source == "S1"]
  r[Source == "S0", S0 := (c0$N1 - n1) / (c0$N - n)]; r[Source == "S1", S1 := (c1$N1 - n1) / (c1$N - n)]
  r <- r[is.finite(S0) & is.finite(S1)]
  z <- qlogis(r$h); y <- r$Source_allele == 1
  ga <- seq(ar[1], ar[2], length.out = n); gc_ <- seq(cr[1], cr[2], length.out = n)
  LP <- outer(ga, gc_, Vectorize(function(a, c) { v <- exp(a); q <- pmin(pmax(r$S0 + (r$S1 - r$S0) * plogis(v * (z - c)), 1e-10), 1 - 1e-10)
     sum(ifelse(y, log(q), log1p(-q))) })) + outer(dnorm(ga, 0, sqrt(10), log = TRUE), dnorm(gc_, 0, sqrt(50), log = TRUE), "+")
  W <- exp(LP - max(LP)); W <- W / sum(W)
  ma <- sum(W * ga); mc <- sum(t(W) * gc_); sa <- sqrt(sum(W * ga^2) - ma^2); sc <- sqrt(sum(t(W) * gc_^2) - mc^2)
  edge <- max(c(W[1, ], W[n, ], W[, 1], W[, n])) / max(W)
  list(ma = ma, mc = mc, sa = sa, sc = sc, edge = edge, W = W, ga = ga, gc = gc_)
}
for (lcs in c("ADFP", "MAP1B", "ARHGAP5", "CLTA")) {
  b <- if (lcs == "MAP1B") brute(lcs, ar = c(-6, 6), cr = c(-40, 40), n = 700) else brute(lcs)
  for (sd in 1:3) {
    f <- ggcline_fast(dp[locus == lcs], he, include.Source = TRUE, loco = TRUE, S = 1000, seed = sd, verbose = FALSE)$gc
    cat(sprintf("%-8s adapt %s seed %d: brute log v %.3f (sd %.3f) fast %.3f [d %.2f sd] | c %.3f (sd %.3f) fast %.3f [d %.2f sd] | fast sd ratio %.2f %.2f | khat %.2f conv %s | grid edge mass %.1e\n",
      lcs, f$is_adapted, sd, b$ma, b$sa, f$mean_log_v, (f$mean_log_v - b$ma)/b$sa, b$mc, b$sc, f$mean_logit_centre, (f$mean_logit_centre - b$mc)/b$sc,
      sqrt(f$var_log_v)/b$sa, sqrt(f$var_logit_centre)/b$sc, f$khat, f$converged, b$edge)) }
  saveRDS(b, paste0("brute_", lcs, ".rds"))
}
