.libPaths(c("/home/claude/rlib", .libPaths()))
suppressPackageStartupMessages({library(gghybrid); library(data.table)})
set.seed(1)
dat  <- read.data("/home/claude/RB_Italy_ggcline_precol_headers_haploidND2.csv",
                  nprecol = 2, MISSINGVAL = NA, NUMINDS = 569)
prep <- data.prep(data = dat$data, loci = dat$loci, alleles = dat$alleles,
                  S0 = c("Kralove", "Oslo"), S1 = "LesinaSPANISH",
                  precols = dat$precols, AF.CIoverlap = FALSE, return.locus.table = TRUE)
saveRDS(list(dat = dat, prep = prep), "prep.rds")
t0 <- proc.time()
hind <- esth(data.prep.object = prep$data.prep, read.data.precols = dat$precols,
             include.Source = TRUE, return.likmeans = TRUE, nitt = 3000, burnin = 1000, print.k = 500)
t_esth <- (proc.time() - t0)[3]
cat("esth time", t_esth, "\n")
saveRDS(list(hind = hind, t = t_esth), "esth_ref.rds")
