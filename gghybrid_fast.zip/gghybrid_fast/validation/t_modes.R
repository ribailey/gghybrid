.libPaths(c("/home/claude/rlib", .libPaths()))
suppressPackageStartupMessages({library(gghybrid); library(data.table)})
source("/mnt/user-data/outputs/gghybrid_fast/R/esth_fast.R"); source("brute.R")
s <- readRDS("prep.rds"); dp <- s$prep$data.prep; pc <- s$dat$precols
## per-locus hybrid index, TEST only
hl <- esth_fast(dp, pc, test.subject = "locus", include.Source = FALSE, verbose = FALSE)
bl <- brute_hi(dp[Source == "TEST"], ts = "locus")
m <- merge(hl$hi, bl, by = "locus")
cat(sprintf("per-locus: max|mean diff|/sd %.1e, max|q97.5 diff|/sd %.1e, cols: %s\n",
  max(abs(m$beta_mean - m$b_mean)/sqrt(m$b_var)), max(abs(m$h_cred_int_upper - m$b_hi)/sqrt(m$b_var)),
  paste(names(hl$hi)[1:3], collapse=",")))
## population-level, and individual-level with test.subject.compare
hp <- esth_fast(dp, pc, test.subject = "POPID", return.likmeans = TRUE, verbose = FALSE)
hi <- esth_fast(dp, pc, test.subject = "INDLABEL", test.subject.compare = "POPID", return.likmeans = TRUE, verbose = FALSE)
cat("POPID rows:", nrow(hp$hi), " npar_compare present:", "npar_compare" %in% names(hi$hi), "\n")
cm <- suppressWarnings(compare.models(esth.object1 = hp, esth.object2 = hi))
print(head(cm[, .(POPID, npar1, npar2, lppd1_sum, lppd2_sum, effpar1_sum, effpar2_sum, waicdiff_effpar_AICscale)], 5))
## fixed subjects
fx <- esth_fast(dp, pc, fix.subject = c("I102", "I105"), fix.value = c(0.9, 1), return.likmeans = TRUE, verbose = FALSE)
print(fx$hi[INDLABEL %in% c("I102", "I105", "I108"), .(INDLABEL, h_posterior_mode, beta_mean, h_cred_int_lower)])
## multi-column test subject
hm <- esth_fast(dp, pc, test.subject = c("POPID", "Source"), verbose = FALSE)
cat("multi-column subjects:", nrow(hm$hi), "\n")
## plot_h compatibility
pdf("plot_h_test.pdf"); ok <- tryCatch({plot_h(data = hi$hi, test.subject = "INDLABEL", POPID.name = "POPID",
  mean.h.by = "POPID", sort.by = c("mean_h", "POPID", "h_posterior_mode"), col.group = "POPID",
  group.sep = "POPID", fill.source = TRUE, basic.lines = FALSE, source.col = c("blue", "red"),
  source.limits = c("blue", "red"), custom.abline = abline(h = 0.5, col = "grey", lty = 2)); TRUE},
  error = function(e) conditionMessage(e)); dev.off()
cat("plot_h works:", ok, "\n")
