.libPaths(c("/home/claude/rlib", .libPaths()))
suppressPackageStartupMessages({library(data.table)})
source("/mnt/user-data/outputs/gghybrid_fast/R/esth_fast.R")
s <- readRDS("prep.rds"); ref <- readRDS("esth_ref.rds"); br <- readRDS("brute.rds")
hf  <- esth_fast(s$prep$data.prep, s$dat$precols, return.likmeans = TRUE, verbose = FALSE)
hfb <- esth_fast(s$prep$data.prep, s$dat$precols, mode.method = "beta", ci.method = "beta", verbose = FALSE)
h0 <- ref$hind$hi
m <- merge(h0, hf$hi, by = "INDLABEL", suffixes = c(".mcmc", ".fast"))
m <- merge(m, hfb$hi[, .(INDLABEL, mode_betafit = h_posterior_mode, lo_b = h_cred_int_lower, hi_b = h_cred_int_upper)], by = "INDLABEL")
m[, sd := sqrt(beta_var.fast)]
cat(sprintf("original esth: %.1f s   esth_fast: %.2f s   (%.0fx)\n", ref$t, hf$elapsed, ref$t/hf$elapsed))
f <- function(lab, x, y) cat(sprintf("%-34s corr %.5f  median|d|/sd %.3f  max|d|/sd %.3f\n",
      lab, cor(x, y, use="c"), median(abs(x-y)/m$sd, na.rm=T), max(abs(x-y)/m$sd, na.rm=T)))
f("posterior mean", m$beta_mean.mcmc, m$beta_mean.fast)
f("posterior sd", sqrt(m$beta_var.mcmc), sqrt(m$beta_var.fast))
f("mode (esth vs fast, Beta-fit rule)", m$h_posterior_mode.mcmc, m$mode_betafit)
f("mode (esth vs fast, exact)", m$h_posterior_mode.mcmc, m$h_posterior_mode.fast)
f("2.5% (esth Beta vs fast exact)", m$h_cred_int_lower.mcmc, m$h_cred_int_lower.fast)
f("97.5% (esth Beta vs fast exact)", m$h_cred_int_upper.mcmc, m$h_cred_int_upper.fast)
cat(sprintf("sd ratio mcmc/exact: median %.3f, range %.3f-%.3f\n", median(sqrt(m$beta_var.mcmc/m$beta_var.fast)),
            min(sqrt(m$beta_var.mcmc/m$beta_var.fast)), max(sqrt(m$beta_var.mcmc/m$beta_var.fast))))
## boundary bias: signed difference in posterior mean by region
m[, region := cut(beta_mean.fast, c(0, .05, .2, .8, .95, 1), include.lowest = TRUE)]
print(m[, .(n = .N, mean_signed_diff_in_sd = mean((beta_mean.mcmc - beta_mean.fast)/sd),
            mean_sd_ratio = mean(sqrt(beta_var.mcmc/beta_var.fast))), keyby = region])
## how different is the Beta-fit mode from the exact mode?
f("exact mode vs Beta-fit mode (both fast)", m$h_posterior_mode.fast, m$mode_betafit)
## WAIC pieces: original esth likmeans vs exact (TEST rows)
src <- unique(s$prep$data.prep[, .(index, Source)])
l0 <- merge(ref$hind$likmeans, src, by = "index")[Source == "TEST"]
l1 <- hf$likmeans
cat(sprintf("TEST rows: lppd  esth %.1f | fast %.1f\n", l0[, sum(log(postmean.exp.loglik))], l1[, sum(log(postmean.exp.loglik))]))
cat(sprintf("TEST rows: p_waic esth %.1f | fast %.1f | TEST individuals (actual npar) %d\n",
            l0[, sum(postmean.loglik.sqrd - postmean.loglik^2)], l1[, sum(postvar.loglik)], hf$hi[Source=="TEST", .N]))
saveRDS(m, "esth_compare.rds")
