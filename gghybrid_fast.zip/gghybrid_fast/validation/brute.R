## Independent brute-force reference for the exact hybrid-index posterior:
## dense uniform grid in phi = asin(sqrt(h)), full log posterior, trapezoid.
brute_hi <- function(dp, prior = c(.5,.5), ngrid = 100001, ts = "INDLABEL") {
  d <- dp[!is.na(Source_allele)]
  cells <- d[, .(n1 = sum(Source_allele==1), n0 = sum(Source_allele==0),
                 S0 = S0.prop_1[1], S1 = S1.prop_1[1]), by = c(ts, "locus")]
  phi <- seq(0, pi/2, length.out = ngrid); h <- sin(phi)^2
  lpr <- (2*prior[1]-1)*log(sin(phi)) + (2*prior[2]-1)*log(cos(phi))
  lpr[!is.finite(lpr)] <- if (prior[1] == .5) 0 else -Inf
  if (prior[1]==.5 && prior[2]==.5) lpr[] <- 0
  cells[, {
    lp <- lpr
    for (j in seq_len(.N)) {
      a <- S0[j] + (S1[j]-S0[j])*h
      t1 <- if (n1[j] > 0) n1[j]*log(a) else 0
      t0 <- if (n0[j] > 0) n0[j]*log1p(-a) else 0
      lp <- lp + t1 + t0
    }
    p <- exp(lp - max(lp)); p[!is.finite(p)] <- 0
    w <- p * c(.5, rep(1, ngrid-2), .5); w <- w/sum(w)
    cw <- cumsum(w)
    ph <- p / sin(2*phi)             # density of h (unnormalised)
    ph[c(1, ngrid)] <- NA
    lm <- which(diff(sign(diff(ph))) == -2) + 1   # interior local maxima
    lm <- lm[p[lm] > 1e-10]
    mode <- if (length(lm)) h[lm[which.max(ph[lm])]] else if (which.max(ph) < ngrid/2) 0 else 1
    list(b_mean = sum(w*h), b_var = sum(w*h^2) - sum(w*h)^2,
         b_lo = h[which(cw >= .025)[1]], b_hi = h[which(cw >= .975)[1]],
         b_med = h[which(cw >= .5)[1]], b_mode = mode)
  }, by = ts]
}
