.libPaths(c("/home/claude/rlib", .libPaths()))
suppressPackageStartupMessages({library(data.table)})
b <- readRDS("brute_MAP1B.rds"); W <- b$W
i <- which(W == max(W), arr.ind = TRUE)
cat(sprintf("brute joint mode: log v %.3f, c %.3f\n", b$ga[i[1]], b$gc[i[2]]))
pa <- rowSums(W); pc <- colSums(W)
q <- function(p, x, w) x[which(cumsum(w) >= p)[1]]
cat("log v quantiles (1,5,25,50,75,95,99%):", sapply(c(.01,.05,.25,.5,.75,.95,.99), q, b$ga, pa), "\n")
cat("c     quantiles (1,5,25,50,75,95,99%):", sapply(c(.01,.05,.25,.5,.75,.95,.99), q, b$gc, pc), "\n")
## conditional sd of c given log v, and posterior mass by log v band
for (lo in c(-6, -1, -0.5, 0, 0.5, 1, 2)) { hi <- lo + ifelse(lo == -6, 5, 0.5); r <- b$ga >= lo & b$ga < hi
  w <- colSums(W[r, , drop = FALSE]); m <- sum(w * b$gc)/sum(w)
  cat(sprintf("log v in [%5.1f,%4.1f): mass %.3f, E[c] %6.2f, sd(c) %5.2f\n", lo, hi, sum(w), m, sqrt(sum(w*(b$gc-m)^2)/sum(w)))) }
## the fast mode and Laplace sds
source("/mnt/user-data/outputs/gghybrid_fast/R/esth_fast.R"); source("/mnt/user-data/outputs/gghybrid_fast/R/ggcline_fast.R")
s <- readRDS("prep.rds"); dp <- s$prep$data.prep; pc0 <- s$dat$precols
chr <- fread("/home/claude/gghybrid/markerchr.csv"); setnames(chr, 1, "locus")
he <- esth_fast(dp, pc0, locus.info = chr, loco = TRUE, verbose = FALSE)
gm <- .gc_mode; .gc_mode <- function(...) { r <- gm(...); assign("MD", r, .GlobalEnv); r }
f <- ggcline_fast(dp[locus == "MAP1B"], he, include.Source = TRUE, loco = TRUE, S = 1000, seed = 1, verbose = FALSE)
cat(sprintf("GN mode: log v %.3f (Laplace sd %.3f), c %.3f (sd %.3f), corr %.2f, iters %d, converged %s\n", MD$a, sqrt(MD$V_aa), MD$cc, sqrt(MD$V_cc),
            MD$V_ac/sqrt(MD$V_aa*MD$V_cc), MD$iters, MD$converged))
