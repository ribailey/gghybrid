.libPaths(c("/home/claude/rlib", .libPaths()))
suppressPackageStartupMessages({library(data.table)})
source("/mnt/user-data/outputs/gghybrid_fast/R/esth_fast.R"); source("/mnt/user-data/outputs/gghybrid_fast/R/ggcline_fast.R")
s <- readRDS("prep.rds"); dp <- s$prep$data.prep; pc <- s$dat$precols
## 12-locus MCMC reference (original ggcline, same esth input, include.Source, source.freq = "all" to match)
o <- readRDS("gc_orig12.rds"); hind <- readRDS("esth_ref.rds")$hind
set.seed(3); keep <- sort(sample(unique(dp$locus), 12)); dps <- dp[locus %in% keep]
f <- ggcline_fast(dps, hind, include.Source = TRUE, source.freq = "all", S = 1000, seed = 5, verbose = FALSE)
g1 <- o$r$gc[order(locus)]; g2 <- f$gc[order(locus)]
cat(sprintf("12 loci vs MCMC: log v corr %.4f max|d|/sd %.3f | logit c corr %.4f max|d|/sd %.3f | sd ratio medians %.2f %.2f | adapted %d | %.1f s vs %.1f s\n",
  cor(g1$mean_log_v, g2$mean_log_v), max(abs(g1$mean_log_v - g2$mean_log_v)/sqrt(g1$var_log_v)),
  cor(g1$mean_logit_centre, g2$mean_logit_centre), max(abs(g1$mean_logit_centre - g2$mean_logit_centre)/sqrt(g1$var_logit_centre)),
  median(sqrt(g2$var_log_v/g1$var_log_v)), median(sqrt(g2$var_logit_centre/g1$var_logit_centre)), sum(g2$is_adapted), f$elapsed, o$t))
## full data, default settings, and with LOCO
chr <- fread("/home/claude/gghybrid/markerchr.csv"); setnames(chr, 1, "locus")
he <- esth_fast(dp, pc, locus.info = chr, loco = TRUE, verbose = FALSE)
for (lc in c(FALSE, TRUE)) {
  r <- ggcline_fast(dp, he, include.Source = TRUE, loco = lc, return.likmeans = TRUE, read.data.precols = pc, S = 500, seed = 1, verbose = FALSE)
  cat(sprintf("72 loci, include.Source + leave-one-out%s: %.1f s, adapted %d, khat>0.7: %d, max khat %.2f, GN converged %d/72, p_waic %.1f (npar %d)\n",
    if (lc) " + LOCO" else "", r$elapsed, sum(r$gc$is_adapted), sum(r$gc$khat > 0.7, na.rm = TRUE), max(r$gc$khat, na.rm = TRUE),
    sum(r$gc$converged), r$likmeans[, sum(postvar.loglik)], r$gc$sum_npar[1]))
}
