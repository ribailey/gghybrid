.libPaths(c("/home/claude/rlib", .libPaths()))
suppressPackageStartupMessages({library(data.table)})
s <- readRDS("prep.rds"); hf <- readRDS("esth_fast.rds"); dp <- s$prep$data.prep
## old version (uploaded), in its own environment
e_old <- new.env(); src <- readLines("/mnt/user-data/uploads/ggcline_fast_complete.R")
src <- src[1:(grep("^## Part 2. Example pipeline", src)[1]-2)]
eval(parse(text = src), envir = e_old)
old <- e_old$ggcline_fast(dp, hf, include.Source = TRUE, return.likmeans = TRUE,
                          read.data.precols = s$dat$precols, S = 1000, seed = 5, verbose = FALSE)
source("/mnt/user-data/outputs/gghybrid_fast/R/ggcline_fast.R")
new <- ggcline_fast(dp, hf, include.Source = TRUE, return.likmeans = TRUE,
                    read.data.precols = s$dat$precols, S = 1000, seed = 5)
g1 <- old$gc; g2 <- new$gc; stopifnot(identical(g1$locus, g2$locus))
cat(sprintf("mean log v   max|diff|/sd %.4f\n", max(abs(g1$mean_log_v-g2$mean_log_v)/sqrt(g2$var_log_v))))
cat(sprintf("mean logit c max|diff|/sd %.4f\n", max(abs(g1$mean_logit_centre-g2$mean_logit_centre)/sqrt(g2$var_logit_centre))))
cat(sprintf("khat: old max %.3f  new max %.3f  corr %.3f\n", max(g1$khat,na.rm=T), max(g2$khat), cor(g1$khat, g2$khat, use="c")))
print(summary(g2$N_eff))
print(names(new$likmeans)); print(nrow(new$likmeans))
lm <- new$likmeans
cat(sprintf("lppd %.1f  p_waic %.1f  npar %d\n", sum(log(lm$postmean.exp.loglik)), sum(lm$postvar.loglik), g2$sum_npar[1]))
print(g2[order(N_eff)][1:4, .(locus, S0.prop_1, S1.prop_1, exp_mean_log_v, v_lower_95, v_upper_95, N_eff, khat)])
