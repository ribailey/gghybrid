.libPaths(c("/home/claude/rlib", .libPaths()))
suppressPackageStartupMessages({library(data.table)})
source("/mnt/user-data/outputs/gghybrid_fast/R/esth_fast.R"); source("/mnt/user-data/outputs/gghybrid_fast/R/ggcline_fast.R")
s <- readRDS("prep.rds"); dp <- s$prep$data.prep; pc <- s$dat$precols

## ---------- p_waic test: original vs patched ggcline, 12 loci ----------
o <- readRDS("gc_orig12.rds"); pt <- readRDS("gc_pat12.rds"); hind <- readRDS("esth_ref.rds")$hind
set.seed(3); keep <- sort(sample(unique(dp$locus), 12)); dps <- dp[locus %in% keep]
fs <- ggcline_fast(dps, hind, include.Source = TRUE, source.freq = "all", return.likmeans = TRUE,
                   read.data.precols = pc, S = 1000, seed = 5, verbose = FALSE)
src <- unique(dp[, .(index, Source)])
w <- function(lm) { l <- merge(lm, src, by = "index", suffixes = c("", ".y")); if ("Source.y" %in% names(l)) l[, Source := Source.y]
  l <- l[Source == "TEST"]; c(lppd = l[, sum(log(postmean.exp.loglik))], p_waic = l[, sum(postmean.loglik.sqrd - postmean.loglik^2)]) }
cat("p_waic test (TEST rows, 12 loci, 24 parameters):\n")
print(rbind(original = w(o$r$likmeans), patched = w(pt$r$likmeans), fast = w(fs$likmeans)))
g0 <- o$r$gc[order(locus)]; g1 <- pt$r$gc[order(locus)]
cat(sprintf("original vs patched parameter means: max|d| log v %.3f SD (same seed, so identical chains expected)\n",
            max(abs(g0$mean_log_v - g1$mean_log_v) / sqrt(g0$var_log_v))))

## ---------- ggcline_fast: new features ----------
chr <- fread("/home/claude/gghybrid/markerchr.csv"); setnames(chr, 1, "locus")
he <- esth_fast(dp, pc, locus.info = chr, loco = TRUE, verbose = FALSE)   # leave-one-out default
a_all <- ggcline_fast(dp, he, include.Source = TRUE, source.freq = "all", return.likmeans = TRUE, read.data.precols = pc, S = 1000, seed = 1, verbose = FALSE)
a_loo <- ggcline_fast(dp, he, include.Source = TRUE, return.likmeans = TRUE, read.data.precols = pc, S = 1000, seed = 1, verbose = FALSE)
a_lc  <- ggcline_fast(dp, he, include.Source = TRUE, loco = TRUE, return.likmeans = TRUE, read.data.precols = pc, S = 1000, seed = 1, verbose = FALSE)
cmpg <- function(lab, x, y) cat(sprintf("%-22s log v: corr %.4f max|d|/sd %.2f | logit c: corr %.4f max|d|/sd %.2f\n", lab,
  cor(x$mean_log_v, y$mean_log_v), max(abs(x$mean_log_v - y$mean_log_v)/sqrt(y$var_log_v)),
  cor(x$mean_logit_centre, y$mean_logit_centre), max(abs(x$mean_logit_centre - y$mean_logit_centre)/sqrt(y$var_logit_centre))))
cmpg("all vs leave-one-out", a_all$gc, a_loo$gc); cmpg("LOO vs LOO+LOCO", a_loo$gc, a_lc$gc)
cat("likmeans rows by Source (LOO):", paste(a_loo$likmeans[, .N, by = Source][, paste(Source, N)], collapse = ", "), "\n")
cat(sprintf("max khat: all %.2f, loo %.2f, loco %.2f\n", max(a_all$gc$khat), max(a_loo$gc$khat), max(a_lc$gc$khat)))

## ---------- brute-force 2-D posterior check of LOO + LOCO wiring ----------
ind_h <- he$hi_loco[, .(INDLABEL, chrom, h = pmin(pmax(h_posterior_mode, 1e-6), 1 - 1e-6))]
cnt <- dp[!is.na(Source_allele) & Source != "TEST", .(N1 = sum(Source_allele == 1), N = .N), by = .(Source, locus)]
own <- dp[!is.na(Source_allele) & Source != "TEST", .(n1 = sum(Source_allele == 1), n = .N), by = .(INDLABEL, Source, locus)]
for (lcs in c("CLTA", "HSDL2", "ND2")) {
  r <- dp[locus == lcs & !is.na(Source_allele)]
  r[, chrom := chr$chrom[match(lcs, chr$locus)]]
  r <- merge(r, ind_h, by = c("INDLABEL", "chrom"))
  r <- merge(r, own[locus == lcs, .(INDLABEL, n1, n)], by = "INDLABEL", all.x = TRUE)
  r[, S0 := S0.prop_1][, S1 := S1.prop_1]
  c0 <- cnt[locus == lcs & Source == "S0"]; c1 <- cnt[locus == lcs & Source == "S1"]
  r[Source == "S0", S0 := (c0$N1 - n1) / (c0$N - n)]; r[Source == "S1", S1 := (c1$N1 - n1) / (c1$N - n)]
  r <- r[is.finite(S0) & is.finite(S1)]
  z <- qlogis(r$h); y <- r$Source_allele == 1
  gr <- expand.grid(a = seq(-3, 4, length.out = 280), c = seq(-4, 4, length.out = 280))
  lp <- apply(gr, 1, function(t) { v <- exp(t[1]); p <- plogis(v * (z - t[2])); q <- pmin(pmax(r$S0 + (r$S1 - r$S0) * p, 1e-10), 1 - 1e-10)
    sum(ifelse(y, log(q), log1p(-q))) }) + dnorm(gr$a, 0, sqrt(10), log = TRUE) + dnorm(gr$c, 0, sqrt(50), log = TRUE)
  wt <- exp(lp - max(lp)); wt <- wt / sum(wt)
  ma <- sum(wt * gr$a); mc <- sum(wt * gr$c); sa <- sqrt(sum(wt * gr$a^2) - ma^2); sc_ <- sqrt(sum(wt * gr$c^2) - mc^2)
  f <- a_lc$gc[locus == lcs]
  cat(sprintf("%-6s brute mean log v %.3f (sd %.3f) fast %.3f | logit c %.3f (sd %.3f) fast %.3f | d/sd %.2f, %.2f\n", lcs,
      ma, sa, f$mean_log_v, mc, sc_, f$mean_logit_centre, (f$mean_log_v - ma)/sa, (f$mean_logit_centre - mc)/sc_))
}
